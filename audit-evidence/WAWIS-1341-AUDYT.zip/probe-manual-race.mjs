import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results=[];
async function pageFor(context){const page=await context.newPage();await page.route('**/__extra_audit__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>isolated extra audit</body>'}));await page.goto('http://127.0.0.1:5073/__extra_audit__');return page;}
try{
 for(let repeat=0;repeat<3;repeat++){
 // An active claim is not permission for another page's manual retry.
 {
  const context=await browser.newContext();try{
   const a=await pageFor(context),b=await pageFor(context);
   await a.evaluate(async()=>{const p=await import('/src/mobile791/modules/photos.js');const q=await import('/src/mobile791/modules/photo-offline-queue.js');const file=new File(['lease-proof-bytes'],'proof.jpg',{type:'image/jpeg'});await q.savePhotoQueueItem({id:'local-photo-upload-claim',job_id:'claim-job',uploaded_by:'claim-owner',local_file:file,prepared_file:file,upload_key:'claim',file_fingerprint:'claim-proof',planned_storage_path:'claim-job/claim.jpg'});const read={select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}};const supabase={auth:{async getUser(){return{data:{user:{id:'claim-owner'}},error:null}}},from:()=>read,storage:{from:()=>({upload:()=>new Promise(resolve=>{window.__releaseA=resolve})})}};window.__workerA=p.resumePersistedPhotoUploads({supabase,profile:{id:'claim-owner'}})});
   await a.waitForFunction(()=>Boolean(window.__releaseA));
   const before=await a.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');const r=(await q.listPhotoQueueItems())[0];return{owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,lease:r.lease_until}});
   await b.evaluate(async()=>{const p=await import('/src/mobile791/modules/photos.js');window.__uploadsB=0;const read={select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}};const supabase={auth:{async getUser(){return{data:{user:{id:'claim-owner'}},error:null}}},from:()=>read,storage:{from:()=>({async upload(){window.__uploadsB++;return{error:{statusCode:403,message:'permission denied'}}}})}};p.retryQueuedJobPhoto({supabase,profile:{id:'claim-owner'},photo:{id:'local-photo-upload-claim'}})});
   await b.waitForFunction(()=>window.__uploadsB>0,{timeout:5000});
   const after=await b.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');let r;for(let i=0;i<50;i++){r=(await q.listPhotoQueueItems())[0];if(r.upload_status==='error')break;await new Promise(r=>setTimeout(r,20))}return{uploadsB:window.__uploadsB,owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,lease:r.lease_until,bytes:await r.local_file.text()}});
   await a.evaluate(async()=>{window.__releaseA({error:{statusCode:403,message:'old worker response'}});await window.__workerA});
   const result={mode:'manual-retry-borrows-active-claim',before,after};results.push(result);console.log(JSON.stringify(result));
  }finally{await context.close()}
 }

}
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/manual-race-results.json',JSON.stringify(results,null,2))}
let failures=0;for(const r of results){try{assert.equal(r.after.uploadsB,0,'Second process must not upload while A holds active lease');assert.equal(r.after.status,'uploading');assert.equal(r.after.lease,r.before.lease)}catch(e){failures++;console.error('RED safety invariant: '+e.message)}}console.log(JSON.stringify({runs:results.length,violated:failures}));process.exitCode=failures?1:0;
