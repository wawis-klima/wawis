import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from '/workspace/wawis/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try {
 const context=await browser.newContext();const page=await context.newPage();const other=await context.newPage();
 await page.goto('http://127.0.0.1:4973');await other.goto('http://127.0.0.1:4973');
 await page.evaluate(async()=>{
  const q=await import('/src/mobile791/modules/photo-offline-queue.js'); const p=await import('/src/mobile791/modules/photos.js');
  const file=new File(['prepared content'],'prepared.jpg',{type:'image/jpeg'});
  await q.savePhotoQueueItem({id:'local-photo-upload-stale',job_id:'audit-job',uploaded_by:'owner-A',upload_key:'stale',file_fingerprint:'stale',planned_storage_path:'audit-job/uploads/stale.jpg',__localFile:file,prepared_file:file,upload_stage:'prepared'});
  const read={select(){return this},eq(){return this},maybeSingle:async()=>({data:null,error:null})};
  const supabase={auth:{getUser:async()=>({data:{user:{id:'owner-A'}},error:null})},from:()=>read,storage:{from:()=>({upload:()=>new Promise(resolve=>{window.__auditResolveUpload=resolve})})}};
  window.__auditResume=p.resumePersistedPhotoUploads({supabase,profile:{id:'owner-A'}});
 });
 await page.waitForFunction(()=>Boolean(window.__auditResolveUpload));
 const secondClaim=await other.evaluate(async()=>{
  const q=await import('/src/mobile791/modules/photo-offline-queue.js');const originalNow=Date.now;
  Date.now=()=>originalNow()+180001;
  try { const claim=await q.claimPhotoQueueItem('local-photo-upload-stale');return{owner:claim.lease_owner,status:claim.upload_status}; }finally{Date.now=originalNow}
 });
 const afterStale=await page.evaluate(async()=>{
  window.__auditResolveUpload({error:{message:'permission denied',status:403}});
  const result=await window.__auditResume;
  const q=await import('/src/mobile791/modules/photo-offline-queue.js');const row=(await q.listPhotoQueueItems())[0];
  return {result,status:row.upload_status,owner:row.lease_owner,error:row.upload_error,lease_until:row.lease_until};
 });
 const evidence={scenario:'Controlled elapsed lease simulates suspended old worker returning after a new claim',secondClaim,afterStale};
 fs.writeFileSync('/tmp/wawis-1340-evidence/concurrency/stale-worker-results.json',JSON.stringify(evidence,null,2)+'\n'); console.log(JSON.stringify(evidence,null,2));
 assert.equal(afterStale.owner,secondClaim.owner);assert.equal(secondClaim.status,'uploading');assert.equal(afterStale.status,'error');
 console.log('Confirmed: old worker overwrote new claim status despite differing lease_owner.');
}finally{await browser.close()}
