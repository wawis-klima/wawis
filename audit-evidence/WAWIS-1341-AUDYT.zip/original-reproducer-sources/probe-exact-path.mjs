import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from '/workspace/wawis/node_modules/@playwright/test/index.mjs';

const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] });
const results = [];
try {
  for (const scenario of ['missing-object', 'wrong-object-bytes', 'legacy-existing-path-wrong-bytes', 'healthy-exact', 'no-row']) {
    const context = await browser.newContext();
    try {
      const page = await context.newPage();
      await page.route('**/__identity_fixture__', route => route.fulfill({ status: 200, contentType: 'text/html', body: '<!doctype html><title>identity fixture</title>' }));
      await page.goto('http://127.0.0.1:4773/__identity_fixture__');
      const result = await page.evaluate(async scenario => {
        const q = await import('/src/mobile791/modules/photo-offline-queue.js');
        const p = await import('/src/mobile791/modules/photos.js');
        async function imageFile(color, name) {
          const canvas = document.createElement('canvas');
          canvas.width = 16; canvas.height = 16;
          const ctx = canvas.getContext('2d'); ctx.fillStyle = color; ctx.fillRect(0, 0, 16, 16);
          return new File([await new Promise(resolve => canvas.toBlob(resolve, 'image/png'))], name, {type: 'image/png'});
        }
        const freshFile = await imageFile('blue', 'new-unsent.png');
        const wrongFile = await imageFile('red', 'server-other.png');
        const jobId = 'audit-exact-job'; const ownerId = 'audit-owner';
        const [doc] = await p.prepareJobDocumentationPhotoIdentities({jobId, documents:[{file:freshFile, deviceIndex:0, unitRef:'jz'}]});
        const identity = doc.uploadIdentity;
        const isLegacyPath = scenario === 'legacy-existing-path-wrong-bytes';
        const plannedPath = isLegacyPath ? `${jobId}/nameplates/old-non-content-addressed.jpg` : identity.plannedStoragePath;
        const record = {
          id: identity.localId, job_id: jobId, uploaded_by: ownerId, user_id: ownerId,
          photo_kind:'nameplate',device_index:1,unit_ref:'jz',created_at:new Date().toISOString(),
          upload_status:'error',__localFile:freshFile,
          upload_key:isLegacyPath?'':identity.uploadKey, file_fingerprint:isLegacyPath?'':identity.fileFingerprint,
          planned_storage_path:plannedPath, legacy_queue_item:isLegacyPath,
        };
        await q.savePhotoQueueItem(record);
        const row = {id:'server-exact-path-row',job_id:jobId,uploaded_by:ownerId,storage_path:plannedPath,image_url:'',photo_kind:'nameplate',device_index:1,unit_ref:'jz',created_at:new Date().toISOString()};
        const rows = scenario==='no-row'?[]:[row];
        let signCalls=0, downloadCalls=0, uploadCalls=0;
        const remoteFile = scenario==='healthy-exact'?freshFile:wrongFile;
        const actualObjectExists = scenario!=='missing-object'&&scenario!=='no-row';
        const supabase = {
          from(name) {
            if(name!=='photos')throw Error('unexpected table');
            const filters=[];
            return {select(){return this},eq(k,v){filters.push([k,v]);return this},
              async maybeSingle(){return{data:rows.find(row=>filters.every(([k,v])=>row[k]===v))||null,error:null}},
              then(resolve,reject){return Promise.resolve({data:rows.filter(row=>filters.every(([k,v])=>row[k]===v)),error:null}).then(resolve,reject)}};
          },
          storage:{from(bucket){if(bucket!=='job-photos')throw Error('unexpected bucket');return{
            async createSignedUrl(path){signCalls++;assertPath(path);return actualObjectExists?{data:{signedUrl:URL.createObjectURL(remoteFile)},error:null}:{data:null,error:{status:404,message:'Object not found'}}},
            async download(path){downloadCalls++;assertPath(path);return actualObjectExists?{data:remoteFile,error:null}:{data:null,error:{status:404,message:'Object not found'}}},
            async upload(){uploadCalls++;throw Error('restore should not upload')},
          }}},
        };
        function assertPath(path){if(path!==plannedPath)throw Error('unexpected queried storage path')}
        let jobs=[{id:jobId,photos:[]}], selected={id:jobId,photos:[]};
        await p.restorePersistedJobPhotos({supabase,profile:{id:ownerId},setJobs:f=>{jobs=f(jobs)},setSelectedJob:f=>{selected=f(selected)}});
        const after=await q.listPhotoQueueItems();
        const stored=after.find(r=>r.id===record.id);
        return {scenario, originalHash:identity.fileFingerprint, remoteHash:actualObjectExists?await p.getPhotoFileFingerprint(remoteFile):null,
          objectExists:actualObjectExists, plannedPath, generatedPath:identity.plannedStoragePath,
          remaining:after.length, retainedBytes:stored?.local_file?await p.getPhotoFileFingerprint(stored.local_file):null,
          uiStatus:selected.photos[0]?.upload_status, uiUsesBlob:selected.photos[0]?.image_url?.startsWith('blob:')||false,
          signCalls,downloadCalls,uploadCalls};
      }, scenario);
      results.push(result);
    } finally { await context.close(); }
  }
} finally { await browser.close(); }
fs.writeFileSync('/tmp/wawis-1340-evidence/identity/exact-path-results.json', JSON.stringify({commit:'76e0e188820014204fb434cf8b87173c8a439900', scope:'Actual unmodified current modules, real browser IndexedDB, controlled metadata/Storage fixtures. Fault states intentionally supplied; not proof those states exist on production.', results}, null, 2)+'\n');
console.log(JSON.stringify(results,null,2));
assert.equal(results.find(x=>x.scenario==='no-row').remaining,1);
assert.equal(results.find(x=>x.scenario==='healthy-exact').remaining,0);
assert.equal(results.find(x=>x.scenario==='missing-object').remaining,0);
assert.equal(results.find(x=>x.scenario==='wrong-object-bytes').remaining,0);
assert.equal(results.find(x=>x.scenario==='legacy-existing-path-wrong-bytes').remaining,0);
console.log('Diagnostic reproduction confirmed current behavior; exit0 means reproduction, not application PASS.');
