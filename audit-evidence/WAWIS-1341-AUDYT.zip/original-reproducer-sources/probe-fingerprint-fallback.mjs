import fs from 'node:fs';
import assert from 'node:assert/strict';
import { chromium } from '/workspace/wawis/node_modules/@playwright/test/index.mjs';
const browser = await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try {
  const page=await browser.newPage();
  await page.route('**/__fingerprint_fixture__',route=>route.fulfill({status:200,contentType:'text/html',body:'<!doctype html><title>fingerprint fixture</title>'}));
  await page.goto('http://127.0.0.1:4773/__fingerprint_fixture__');
  const result=await page.evaluate(async()=>{
    const p=await import('/src/mobile791/modules/photos.js');
    const q=await import('/src/mobile791/modules/photo-offline-queue.js');
    async function png(color){const c=document.createElement('canvas');c.width=16;c.height=16;const x=c.getContext('2d');x.fillStyle=color;x.fillRect(0,0,16,16);return await new Promise(r=>c.toBlob(r,'image/png'))}
    const a=await png('blue'),b=await png('red'),max=Math.max(a.size,b.size);
    const files=[a,b].map(blob=>new File([blob,new Uint8Array(max-blob.size)],'nameplate.png',{type:'image/png',lastModified:1}));
    const trueHashes=await Promise.all(files.map(f=>p.getPhotoFileFingerprint(f)));
    const decodes=await Promise.all(files.map(async f=>{const img=await createImageBitmap(f);return [img.width,img.height]}));
    for(const file of files)Object.defineProperty(file,'arrayBuffer',{value:async()=>{throw new DOMException('Synthetic Blob read failure','NotReadableError')}});
    const fallbackHashes=await Promise.all(files.map(f=>p.getPhotoFileFingerprint(f)));
    Object.defineProperty(Navigator.prototype,'onLine',{configurable:true,get:()=>false});
    const owner='fallback-owner',jobId='fallback-job';
    const supabase={auth:{getUser:async()=>({data:{user:{id:owner}},error:null})}};
    let jobs=[{id:jobId,photos:[]}];
    const states=[];
    for(const file of files){
      const upload=await p.uploadJobDocumentationPhotos({supabase,profile:{id:owner},jobId,documents:[{file,deviceIndex:0,unitRef:'jz'}],setJobs:f=>{jobs=f(jobs)}});
      const records=await q.listPhotoQueueItems();
      states.push({upload,recordCount:records.length,ids:records.map(r=>r.id),storedOriginalHashes:await Promise.all(records.map(r=>p.getPhotoFileFingerprint(r.local_file))),metadataFingerprint:records[0]?.file_fingerprint});
    }
    return {injectedFault:'File.arrayBuffer throws NotReadableError; valid PNG bytes remain available for native Image decoding and IndexedDB structured clone',trueHashes,fallbackHashes,sizes:files.map(f=>f.size),decodes,states};
  });
  fs.writeFileSync('/tmp/wawis-1340-evidence/identity/fingerprint-fallback-results.json',JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));
  assert.notEqual(result.trueHashes[0],result.trueHashes[1]);
  assert.equal(result.fallbackHashes[0],result.fallbackHashes[1]);
  assert.equal(result.states[0].recordCount,1);
  assert.equal(result.states[1].recordCount,1);
  assert.equal(result.states[1].storedOriginalHashes[0],result.trueHashes[1]);
  assert.notEqual(result.states[1].storedOriginalHashes[0],result.trueHashes[0]);
  console.log('Current fault reproduced: second distinct file overwrites first durable unsent file after metadata-only fingerprint fallback. Exit0 is diagnostic, not app PASS.');
}finally{await browser.close()}
