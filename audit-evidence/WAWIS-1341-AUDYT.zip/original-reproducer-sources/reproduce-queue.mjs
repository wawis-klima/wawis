import assert from 'node:assert/strict';
import fs from 'node:fs';
import { chromium } from '/workspace/wawis/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
try {
  const page=await browser.newPage();
  await page.goto('http://127.0.0.1:4973');
  const results=await page.evaluate(async()=>{
    const queue=await import('/src/mobile791/modules/photo-offline-queue.js');
    const photos=await import('/src/mobile791/modules/photos.js');
    const file=new File([new Uint8Array([1,2,3,4])],'same.jpg',{type:'image/jpeg'});
    Object.defineProperty(Navigator.prototype,'onLine',{configurable:true,get:()=>false});
    const supaForOwner=id=>({auth:{getUser:async()=>({data:{user:{id}},error:null})}});
    for(const id of ['owner-A','owner-B']) {
      await photos.uploadJobPhotos({supabase:supaForOwner(id),profile:{id},jobId:'audit-shared-job',event:{target:{files:[file],value:'selected'}}});
    }
    let rows=await queue.listPhotoQueueItems();
    const ownerCollision={count:rows.length,owners:rows.map(x=>x.user_id),ids:rows.map(x=>x.id)};
    for(const row of rows) await queue.deletePhotoQueueItem(row.id);
    Object.defineProperty(Navigator.prototype,'onLine',{configurable:true,get:()=>true});
    const base={id:'local-photo-upload-audit-permanent',job_id:'audit-job',uploaded_by:'owner-A',upload_key:'audit-permanent',file_fingerprint:'fingerprint',planned_storage_path:'audit-job/uploads/permanent.jpg',__localFile:file,prepared_file:file,upload_stage:'prepared',upload_status:'error',upload_error:'permission denied',retry_count:1};
    await queue.savePhotoQueueItem(base);
    let attempts=0;
    const read={select(){return this},eq(){return this},maybeSingle:async()=>({data:null,error:null})};
    const supabase={auth:{getUser:async()=>({data:{user:{id:'owner-A'}},error:null})},from:()=>read,storage:{from:()=>({upload:async()=>{attempts++;return{error:{message:'permission denied',status:403}}}})}};
    const first=await photos.resumePersistedPhotoUploads({supabase,profile:{id:'owner-A'}});
    const afterFirst=(await queue.listPhotoQueueItems())[0];
    const second=await photos.resumePersistedPhotoUploads({supabase,profile:{id:'owner-A'}});
    const afterSecond=(await queue.listPhotoQueueItems())[0];
    return {ownerCollision,errorAutoRetry:{attempts,first,second,afterFirst:{status:afterFirst.upload_status,retry:afterFirst.retry_count,next:afterFirst.next_attempt_at},afterSecond:{status:afterSecond.upload_status,retry:afterSecond.retry_count,next:afterSecond.next_attempt_at}}};
  });
  fs.writeFileSync('/tmp/wawis-1340-evidence/concurrency/queue-results.json',JSON.stringify(results,null,2)+'\n');
  console.log(JSON.stringify(results,null,2));
  assert.equal(results.ownerCollision.count,1);
  assert.deepEqual(results.ownerCollision.owners,['owner-B']);
  assert.equal(results.errorAutoRetry.attempts,2);
  console.log('Confirmed current behavior: A record overwritten by B; permanent errors auto-retried twice without includeErrors.');
} finally {await browser.close()}
