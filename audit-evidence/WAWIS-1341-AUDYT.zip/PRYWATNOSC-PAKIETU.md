Wersja pakietu przygotowana do przekazania przez prywatne repozytorium GitHub.

Zachowano wszystkie pliki, reproduktory, wyniki i wnioski oryginalnego audytu.
Raport RAPORT-KONCOWY-1341.md pozostał niezmieniony.
Zredagowano hasło konta testowego, syntetyczną wartość Bearer, wartości tokenów
formularzy GitHub oraz realistyczne dane osobowe fixture w tekstach i PDF.
Redakcja dotyczy również zagnieżdżonych ZIP-ów i zasobów śladów Playwright.
Nie zmieniono kodu aplikacji ani wyników i liczników testów.

Kontrola objęła teksty, archiwa, bazy profili przeglądarki i PDF. Profile nie
zawierały zapisanych loginów, cookies, kart ani danych autouzupełniania.
OCR obejmował 18 obrazów zewnętrznych i 549 unikalnych obrazów ze śladów.
Nie wykryto rzeczywistych kluczy API, JWT, tokenów GitHub ani kluczy prywatnych.
Jawne znaczniki dokumentacji SDK typu <ACCESS_TOKEN> są placeholderami.

Sumy kontrolne wewnątrz archiwów dotyczą tej zanonimizowanej wersji.
Oryginalne, niepublikowane dowody pozostały niezmienione w środowisku audytu.
