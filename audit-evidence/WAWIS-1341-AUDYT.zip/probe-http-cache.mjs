import fs from 'node:fs';
import http from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
let bytes=null,present=true,reads=0;const requests=[];
const server=http.createServer(async(req,res)=>{
 if(req.url==='/'){res.writeHead(200,{'content-type':'text/html','cache-control':'no-store'});res.end('<!doctype html><body>HTTP cache integrity audit</body>');return}
 if(req.url==='/__seed'){const chunks=[];for await(const chunk of req)chunks.push(chunk);bytes=Buffer.concat(chunks);res.end('seeded');return}
 if(req.url==='/__remove'){present=false;res.end('removed');return}
 if(req.url.startsWith('/storage/v1/object/')){
  if(req.method==='GET')reads++;requests.push({method:req.method,url:req.url,present,authorization:!!req.headers.authorization});
  if(!present){res.writeHead(404,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify({statusCode:404,error:'not_found',message:'Object missing'}));return}
  res.writeHead(200,{'content-type':'image/png','cache-control':'private, max-age=3600','content-length':bytes.length,'etag':'"fixture-object-v1"'});res.end(bytes);return
 }
 try{const r=await fetch('http://127.0.0.1:5073'+req.url);res.writeHead(r.status,{'content-type':r.headers.get('content-type')||'text/javascript','cache-control':'no-store'});res.end(Buffer.from(await r.arrayBuffer()))}catch(e){res.writeHead(502);res.end(String(e))}
});
await new Promise(r=>server.listen(5883,'127.0.0.1',r));
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});let result={scope:'Real Chromium HTTP cache + real Supabase JS storage.download + real13.41 queue/verification; controlled local HTTP Storage with private max-age3600; production cache headers not observed'};
try{
 const page=await browser.newPage();await page.goto('http://127.0.0.1:5883/');
 result.browser=await page.evaluate(async()=>{
  const {createClient}=await import('/node_modules/.vite/deps/@supabase_supabase-js.js');
  const sdk=createClient('http://127.0.0.1:5883','audit-public-placeholder',{auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false}});
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');
  const c=document.createElement('canvas');c.width=16;c.height=16;c.getContext('2d').fillRect(0,0,16,16);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([blob],'cached.png',{type:'image/png',lastModified:1});
  await fetch('/__seed',{method:'POST',body:blob});const path='cache-job/cached.png';
  await q.savePhotoQueueItem({id:'local-photo-upload-cached',job_id:'cache-job',uploaded_by:'cache-owner',local_file:file,prepared_file:file,upload_key:'cache-proof',file_fingerprint:'cache-proof',planned_storage_path:path});
  const supabase={storage:sdk.storage,from(){return{select(){return this},eq(){return this},async maybeSingle(){return{data:{id:'cache-row',job_id:'cache-job',storage_path:path,uploaded_by:'cache-owner'},error:null}}}}};
  const active=await q.claimPhotoQueueItem('local-photo-upload-cached');
  // First real restore verifies bytes but cannot delete another active claim.
  const firstRestore=await p.restorePersistedJobPhotos({supabase,profile:{id:'cache-owner'}});
  const primeRetained=(await q.listPhotoQueueItems()).length;
  await q.releaseClaimedPhotoQueueItem('local-photo-upload-cached',active);
  await fetch('/__remove',{method:'POST'});
  const restored=await p.restorePersistedJobPhotos({supabase,profile:{id:'cache-owner'}});
  const remaining=(await q.listPhotoQueueItems()).length;
  const fresh=await sdk.storage.from('job-photos').download(path,{cacheNonce:String(Date.now())},{cache:'no-store'});
  return{primedBytes:file.size,firstRestoreCount:firstRestore.length,primeRetained,remaining,restored:restored.length,freshStatus:Number(fresh.error?.status||fresh.error?.statusCode||0),freshBytes:fresh.data?.size||0};
 });
 result.server={present,reads,requests};
 const cdp=await page.context().newCDPSession(page);await cdp.send('Network.clearBrowserCache');await page.reload();
 result.afterCacheEvictionAndReload=await page.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');const fresh=await fetch('/storage/v1/object/job-photos/cache-job/cached.png',{cache:'no-store'});return{queueCount:(await q.listPhotoQueueItems()).length,originStatus:fresh.status}});
 console.log(JSON.stringify(result,null,2));
 assert.equal(result.browser.remaining,1,'Cached download must not authorize deletion of last local Blob after origin object was removed');
}finally{await browser.close();server.closeAllConnections();await new Promise(r=>server.close(r));fs.writeFileSync('/tmp/wawis-1341-evidence/http-cache-results.json',JSON.stringify(result,null,2))}
