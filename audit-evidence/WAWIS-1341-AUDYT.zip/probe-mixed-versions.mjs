import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});let result={scope:'Concurrent real13.40 and13.41 photo modules on SAME origin and real IndexedDB; controlled transport ACK without stored object; not installed native PWA'};
try{
 const ctx=await browser.newContext();const a=await ctx.newPage(),b=await ctx.newPage();
 await a.route('**/*',async route=>{const u=new URL(route.request().url());if(u.pathname==='/__mixed_audit__'){await route.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>13.40 old client</body>'});return}u.port='5483';const response=await route.fetch({url:u.toString()});await route.fulfill({response})});
 await b.route('**/__mixed_audit__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>13.41 new client</body>'}));
 for(const page of [a,b])await page.goto('http://127.0.0.1:5073/__mixed_audit__');
 result.oldClient=await a.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');
  const c=document.createElement('canvas');c.width=16;c.height=16;c.getContext('2d').fillRect(0,0,16,16);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const f=new File([blob],'mixed.png',{type:'image/png',lastModified:1});
  await q.savePhotoQueueItem({id:'local-photo-upload-mixed',job_id:'mixed-job',uploaded_by:'mixed-owner',local_file:f,prepared_file:f,upload_key:'mixed',file_fingerprint:'mixed-proof',planned_storage_path:'mixed-job/mixed.jpg'});
  window.__serverRows=[];
  const supabase={auth:{async getUser(){return{data:{user:{id:'mixed-owner'}},error:null}}},from(){return{select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}},insert(data){return{select(){return{async single(){const row={...data,id:'mixed-server-row'};window.__serverRows.push(row);return{data:row,error:null}}}}}}}},storage:{from:()=>({upload:()=>new Promise(r=>window.__releaseOld=r),async createSignedUrl(){return{data:{signedUrl:'https://audit.invalid/absent-photo'},error:null}}})}};
  window.__oldWork=p.resumePersistedPhotoUploads({supabase,profile:{id:'mixed-owner'}});
  return{hasGenerationFence:q.claimPhotoQueueItem.toString().includes('attempt_generation'),originalBytes:f.size};
 });
 await a.waitForFunction(()=>!!window.__releaseOld);
 result.newClient=await b.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');const now=Date.now;window.__realNow=now;Date.now=()=>now()+180001;
  const supabase={auth:{async getUser(){return{data:{user:{id:'mixed-owner'}},error:null}}},from(){return{select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}}},storage:{from:()=>({upload:()=>new Promise(r=>window.__releaseNew=r)})}};
  window.__newWork=p.resumePersistedPhotoUploads({supabase,profile:{id:'mixed-owner'}});
  return{hasGenerationFence:q.claimPhotoQueueItem.toString().includes('attempt_generation')};
 });
 await b.waitForFunction(()=>!!window.__releaseNew);
 result.beforeOldResponse=await b.evaluate(async()=>{Date.now=window.__realNow;const q=await import('/src/mobile791/modules/photo-offline-queue.js');const r=(await q.listPhotoQueueItems())[0];return{count:1,owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,bytes:r.local_file.size}});
 await a.evaluate(async()=>{window.__releaseOld({data:{path:'mixed-job/mixed.jpg'},error:null});await window.__oldWork});
 result.afterOldResponse=await b.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');return{queueCount:(await q.listPhotoQueueItems()).length}});
 result.serverRows=await a.evaluate(()=>window.__serverRows);result.serverObjectCount=0;
 await b.evaluate(async()=>{window.__releaseNew({data:null,error:{statusCode:403,message:'new upload failed before commit'}});await window.__newWork});
 result.finalQueueCount=await b.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');return(await q.listPhotoQueueItems()).length});
 assert.equal(result.oldClient.hasGenerationFence,false);assert.equal(result.newClient.hasGenerationFence,true);
 console.log(JSON.stringify(result,null,2));
 // RED against the invariant: newer process must retain the last durable Blob.
 assert.equal(result.finalQueueCount,1,'Mixed-version old worker deleted newer client durable Blob while no server object exists');
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/mixed-versions-results.json',JSON.stringify(result,null,2))}
