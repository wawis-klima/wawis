import fs from 'node:fs';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});let result;
try{
 const ctx=await browser.newContext();const a=await ctx.newPage(),b=await ctx.newPage();
 for(const page of [a,b]){await page.route('**/__stale_network__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>stale network audit</body>'}));await page.goto('http://127.0.0.1:5073/__stale_network__')}
 await a.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');const f=new File(['stale-proof'],'p.jpg',{type:'image/jpeg'});
  await q.savePhotoQueueItem({id:'local-photo-upload-stale-network',job_id:'stale-job',uploaded_by:'stale-owner',local_file:f,prepared_file:f,upload_key:'stale',file_fingerprint:'stale-proof',planned_storage_path:'stale-job/p.jpg'});
  window.__uploads=0;
  const supabase={auth:{getUser:()=>new Promise(r=>{window.__releaseAuth=r})},from(){return{select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}}},storage:{from:()=>({async upload(){window.__uploads++;return{error:{statusCode:403,message:'controlled stale upload'}}}})}};
  window.__work=p.resumePersistedPhotoUploads({supabase,profile:{id:'stale-owner'}});
 });
 await a.waitForFunction(()=>!!window.__releaseAuth);
 const second=await b.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');const now=Date.now;Date.now=()=>now()+180001;try{const c=await q.claimPhotoQueueItem('local-photo-upload-stale-network');return{owner:c.lease_owner,generation:c.attempt_generation}}finally{Date.now=now}});
 await a.evaluate(async()=>{window.__releaseAuth({data:{user:{id:'stale-owner'}},error:null});await window.__work});
 result=await a.evaluate(async second=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');const r=(await q.listPhotoQueueItems())[0];return{second,staleUploadsAfterTakeover:window.__uploads,current:{owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,bytes:await r.local_file.text()}}},second);
 console.log(JSON.stringify(result,null,2));await ctx.close();
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/stale-network-results.json',JSON.stringify(result,null,2))}
