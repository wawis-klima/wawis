import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
const base='/tmp/wawis-1341-evidence/original-invariants';
const tests=[
 {name:'R1',file:'/tmp/wawis-1340-evidence/identity/probe-exact-path.mjs',port:4773,tail:"assert.equal(results.find(x=>x.scenario==='no-row').remaining,1);\nassert.equal(results.find(x=>x.scenario==='healthy-exact').remaining,0);\nfor(const name of ['missing-object','wrong-object-bytes','legacy-existing-path-wrong-bytes'])assert.equal(results.find(x=>x.scenario===name).remaining,1,name);\n"},
 {name:'R2',file:'/tmp/wawis-1340-evidence/identity/probe-fingerprint-fallback.mjs',port:4773},
 {name:'C1-C2',file:'/tmp/wawis-1340-evidence/concurrency/reproduce-queue.mjs',port:4973},
 {name:'C3',file:'/tmp/wawis-1340-evidence/concurrency/reproduce-stale-worker.mjs',port:4973},
];
const summary=[];
for(const version of ['1340','1341'])for(const test of tests){
 const dest=`${base}/${version}/${test.name}`;fs.mkdirSync(dest,{recursive:true});
 let s=fs.readFileSync(test.file,'utf8').replaceAll(`http://127.0.0.1:${test.port}`,`http://127.0.0.1:${version==='1340'?5483:5073}`).replaceAll('/tmp/wawis-1340-evidence/identity/',dest+'/').replaceAll('/tmp/wawis-1340-evidence/concurrency/',dest+'/');
 if(test.name==='R1')s=s.slice(0,s.indexOf("assert.equal(results.find(x=>x.scenario==='no-row')"))+test.tail;
 if(test.name==='R2')s=s.slice(0,s.indexOf('  assert.notEqual(result.trueHashes'))+"  assert.notEqual(result.trueHashes[0],result.trueHashes[1]);\n  assert.equal(result.states[0].recordCount,1);\n  assert.equal(result.states[1].recordCount,2);\n  assert.deepEqual(result.states[1].storedOriginalHashes.slice().sort(),result.trueHashes.slice().sort());\n}finally{await browser.close()}\n";
 if(test.name==='C1-C2')s=s.slice(0,s.indexOf('  assert.equal(results.ownerCollision.count'))+"  assert.equal(results.ownerCollision.count,2);\n  assert.deepEqual(results.ownerCollision.owners.slice().sort(),['owner-A','owner-B']);\n  assert.equal(results.errorAutoRetry.attempts,0);\n}finally{await browser.close()}\n";
 if(test.name==='C3')s=s.slice(0,s.indexOf(' assert.equal(afterStale.owner'))+" assert.equal(afterStale.owner,secondClaim.owner);assert.equal(secondClaim.status,'uploading');assert.equal(afterStale.status,'uploading');assert.ok(afterStale.lease_until);\n}finally{await browser.close()}\n";
 const r=spawnSync(process.execPath,['--input-type=module','-'],{input:s,encoding:'utf8',timeout:120000});fs.writeFileSync(dest+'/run.log',r.stdout+'\n'+r.stderr);const item={version,test:test.name,exit_code:r.status,error:r.error?.message};summary.push(item);console.log(JSON.stringify(item));
}
fs.writeFileSync(base+'/summary.json',JSON.stringify(summary,null,2));
