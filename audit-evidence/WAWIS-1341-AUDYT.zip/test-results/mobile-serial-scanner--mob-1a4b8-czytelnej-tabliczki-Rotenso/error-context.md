# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-serial-scanner.spec.js >> @mobile iPhone — uproszczony kreator urządzeń bez OCR z kadrowaniem tabliczek >> automatycznie odczytuje prawdziwe pola modelu i SN z czytelnej tabliczki Rotenso
- Location: tests/e2e/mobile-serial-scanner.spec.js:503:3

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e3]:
    - generic "Przełączanie modułów aplikacji" [ref=e5]:
      - button "Montaże" [ref=e6] [cursor=pointer]:
        - generic [ref=e7]: Montaże
      - button "Paliwo" [ref=e8] [cursor=pointer]:
        - generic [ref=e9]: Paliwo
      - button "Cennik" [ref=e10] [cursor=pointer]:
        - generic [ref=e11]: Cennik
    - generic [ref=e14]:
      - generic [ref=e15]: W trakcie
      - generic [ref=e16]:
        - generic [ref=e17]:
          - button "Wersja aplikacji 13.41 — otwórz diagnostykę" [ref=e18]: v13.41
          - button "Dodaj nowego klienta" [ref=e19]:
            - img [ref=e20]
          - button "Synchronizuj dane" [ref=e22]:
            - img [ref=e23]
          - generic "Powiadomienia push" [ref=e26]:
            - button "PUSH · brak konfiguracji. Włącz PUSH." [ref=e27] [cursor=pointer]:
              - generic [ref=e28]: PUSH
              - generic [ref=e32]: "OFF"
          - button "Filtruj zlecenia" [ref=e33]:
            - img [ref=e34]
          - button "Wyloguj użytkownika Pracownik Testowy" [ref=e36] [cursor=pointer]: PT
        - 'status "Połączenie: Średnie. Wszystko wysłane. Kliknij, aby otworzyć centrum synchronizacji." [ref=e37]':
          - button "Otwórz Centrum synchronizacji" [ref=e38] [cursor=pointer]:
            - generic [ref=e39]: "Połączenie: Średnie"
            - generic [ref=e41]:
              - text: Wszystko wysłane
              - generic [ref=e43]: ›
      - generic "Statusy zleceń" [ref=e44]:
        - 'button "Nowe: 1" [ref=e45] [cursor=pointer]':
          - generic [ref=e46]:
            - img [ref=e47]
            - generic: "1"
        - 'button "W trakcie: 3" [ref=e48] [cursor=pointer]':
          - generic [ref=e49]:
            - img [ref=e50]
            - generic: "3"
        - 'button "Niezrealizowane: 0" [ref=e51] [cursor=pointer]':
          - generic [ref=e52]:
            - img [ref=e53]
            - generic: "0"
        - 'button "Zakończone: 1" [ref=e54] [cursor=pointer]':
          - generic [ref=e55]:
            - img [ref=e56]
            - generic: "1"
      - generic [ref=e57]:
        - generic [ref=e58]:
          - generic [ref=e59]:
            - button [ref=e60] [cursor=pointer]:
              - img [ref=e61]
              - generic [ref=e64]: Tabliczki
            - button [disabled] [ref=e65]:
              - img [ref=e66]
              - generic [ref=e69]: Protokół
          - generic [ref=e70]:
            - link [ref=e71] [cursor=pointer]:
              - /url: tel:500800900
              - img [ref=e72]
              - generic [ref=e74]: Zadzwoń
            - link [ref=e75] [cursor=pointer]:
              - /url: https://www.google.com/maps/search/?api=1&query=Zawiercie%2C%20Multi-Splitowa%203
              - img [ref=e76]
              - generic [ref=e79]: Nawiguj
          - button "Klient Testowy Multi-Split 24.07.26 Zawiercie, Multi-Splitowa 3 PT W trakcie" [expanded] [ref=e82] [cursor=pointer]:
            - generic [ref=e83]:
              - strong [ref=e84]: Klient Testowy Multi-Split
              - generic [ref=e85]: 24.07.26
            - generic [ref=e88]: Zawiercie, Multi-Splitowa 3
            - generic [ref=e89]:
              - generic "Pracownik Testowy" [ref=e92]: PT
              - generic [ref=e93]: W trakcie
        - generic [ref=e97]:
          - generic [ref=e99]:
            - heading "Klient Testowy Multi-Split" [level=2] [ref=e100]
            - generic [ref=e101]:
              - generic [ref=e102]:
                - generic [ref=e103]:
                  - img [ref=e104]
                  - generic [ref=e107]: Email
                - link "Wyślij email do multi.test@example.test" [ref=e110] [cursor=pointer]:
                  - /url: mailto:multi.test@example.test
                  - text: multi.test@example.test
              - generic [ref=e111]:
                - generic [ref=e112]:
                  - img [ref=e113]
                  - generic [ref=e115]: Telefon
                - link "Zadzwoń pod numer 500800900" [ref=e118] [cursor=pointer]:
                  - /url: tel:500800900
                  - text: "500800900"
              - generic [ref=e119]:
                - generic [ref=e120]:
                  - img [ref=e121]
                  - generic [ref=e124]: Adres
                - 'link "Otwórz adres w Google Maps: Zawiercie, Multi-Splitowa 3" [ref=e126] [cursor=pointer]':
                  - /url: https://www.google.com/maps/search/?api=1&query=Zawiercie%2C%20Multi-Splitowa%203
                  - text: Zawiercie, Multi-Splitowa 3
              - generic [ref=e127]:
                - generic [ref=e128]:
                  - img [ref=e129]
                  - generic [ref=e132]: Data
                - generic [ref=e133]: 24.07.26
              - generic [ref=e134]:
                - generic [ref=e135]:
                  - generic [ref=e136]:
                    - img [ref=e137]
                    - generic [ref=e140]: Urządzenia i tabliczki
                  - generic [ref=e141]: Multi-split
                - button "Rozwiń Urządzenie 1" [ref=e145] [cursor=pointer]:
                  - strong [ref=e146]: Urządzenie 1
                  - generic [ref=e147]: Multi-split
              - generic [ref=e148]:
                - generic [ref=e149]:
                  - img [ref=e150]
                  - generic [ref=e155]: Monterzy
                - generic "Pracownik Testowy" [ref=e158]: PT
              - generic [ref=e159]:
                - generic [ref=e160]:
                  - img [ref=e161]
                  - generic [ref=e164]: Data utworzenia
                - generic [ref=e165]: 24.07.26
            - generic [ref=e166]:
              - button "Edytuj" [ref=e167] [cursor=pointer]:
                - generic [ref=e168]: Edytuj
              - button "Tabliczki" [ref=e169] [cursor=pointer]:
                - generic [ref=e170]: Tabliczki
              - button "Zakończ" [disabled] [ref=e171]:
                - generic [ref=e172]: Zakończ
              - button "Protokół" [disabled] [ref=e173]:
                - generic [ref=e174]: Protokół
              - button "Zamknij" [ref=e175] [cursor=pointer]:
                - generic [ref=e176]: Zamknij
            - generic [ref=e177]: "Krok 1/3: uzupełnij i zsynchronizuj tabliczki. Dopiero potem aktywuje się „Protokół”."
          - generic [ref=e178]:
            - heading "Komentarz administratora" [level=4] [ref=e179]:
              - img [ref=e180]
              - generic [ref=e183]: Komentarz administratora
            - generic [ref=e187]: "Karta testowa multi-split: jeden agregat i trzy jednostki wewnętrzne."
          - generic [ref=e188]:
            - heading "Zdjęcia" [level=4] [ref=e189]:
              - img [ref=e190]
              - generic [ref=e193]: Zdjęcia
            - generic [ref=e196]:
              - generic [ref=e198]: Brak zdjęć.
              - generic "Dodawanie zdjęć do zlecenia" [ref=e199]:
                - generic [ref=e200] [cursor=pointer]:
                  - img [ref=e202]
                  - generic [ref=e205]: Aparat
                - generic [ref=e206] [cursor=pointer]:
                  - img [ref=e208]
                  - generic [ref=e212]: Galeria
          - generic [ref=e213]:
            - heading "Monterzy" [level=4] [ref=e214]:
              - img [ref=e215]
              - generic [ref=e220]: Monterzy
            - generic "Wybór monterów" [ref=e224]:
              - button "Administrator Testowy — Nie monter" [ref=e225] [cursor=pointer]:
                - generic [ref=e226]: A. Testowy
              - button "Pracownik Testowy — główny monter (zmiana w edycji montażu)" [disabled] [ref=e227] [cursor=pointer]:
                - generic [ref=e228]: P. Testowy
          - generic [ref=e229]:
            - heading "Komentarze i pytania" [level=4] [ref=e230]:
              - img [ref=e231]
              - generic [ref=e233]: Komentarze i pytania
            - generic [ref=e236]:
              - generic [ref=e238]: Brak komentarzy.
              - textbox "Napisz komentarz..." [ref=e239]
              - button "Dodaj komentarz" [disabled] [ref=e241]
        - generic [ref=e242]:
          - generic [ref=e243]:
            - button [ref=e244] [cursor=pointer]:
              - img [ref=e245]
              - generic [ref=e248]: Tabliczki
            - button [disabled] [ref=e249]:
              - img [ref=e250]
              - generic [ref=e253]: Protokół
          - generic [ref=e254]:
            - link [ref=e255] [cursor=pointer]:
              - /url: tel:500700800
              - img [ref=e256]
              - generic [ref=e258]: Zadzwoń
            - link [ref=e259] [cursor=pointer]:
              - /url: https://www.google.com/maps/search/?api=1&query=%C5%81%C3%B3d%C5%BA%2C%20Obca%204
              - img [ref=e260]
              - generic [ref=e263]: Nawiguj
          - button "Klient Testowy D Cudzy 07.05.26 Łódź, Obca 4 AT W trakcie" [ref=e266] [cursor=pointer]:
            - generic [ref=e267]:
              - strong [ref=e268]: Klient Testowy D Cudzy
              - generic [ref=e269]: 07.05.26
            - generic [ref=e272]: Łódź, Obca 4
            - generic [ref=e273]:
              - generic "Administrator Testowy" [ref=e276]: AT
              - generic [ref=e277]: W trakcie
        - generic [ref=e278]:
          - generic [ref=e279]:
            - button [ref=e280] [cursor=pointer]:
              - img [ref=e281]
              - generic [ref=e284]: Tabliczki
            - button [disabled] [ref=e285]:
              - img [ref=e286]
              - generic [ref=e289]: Protokół
          - generic [ref=e290]:
            - link [ref=e291] [cursor=pointer]:
              - /url: tel:500300400
              - img [ref=e292]
              - generic [ref=e294]: Zadzwoń
            - link [ref=e295] [cursor=pointer]:
              - /url: https://www.google.com/maps/search/?api=1&query=Krak%C3%B3w%2C%20Ch%C5%82odna%205
              - img [ref=e296]
              - generic [ref=e299]: Nawiguj
          - button "Klient Testowy B 05.05.26 Kraków, Chłodna 5 PT W trakcie" [ref=e302] [cursor=pointer]:
            - generic [ref=e303]:
              - strong [ref=e304]: Klient Testowy B
              - generic [ref=e305]: 05.05.26
            - generic [ref=e308]: Kraków, Chłodna 5
            - generic [ref=e309]:
              - generic "Pracownik Testowy" [ref=e312]: PT
              - generic [ref=e313]: W trakcie
  - dialog [ref=e314]:
    - generic [ref=e315]:
      - generic [ref=e316]:
        - button "Wróć" [ref=e317] [cursor=pointer]:
          - img [ref=e318]
        - heading "Jednostka JW1" [level=2] [ref=e320]
        - button "Zamknij" [ref=e321] [cursor=pointer]
      - generic [ref=e322]:
        - generic [ref=e323]: •••
        - text: Krok 3 z 4
      - generic [ref=e324]:
        - generic [ref=e325]:
          - img [ref=e326]
          - text: Jednostka wewnętrzna JW1
        - generic [ref=e330]:
          - button "Tabliczka znamionowa Jednostka wewnętrzna JW1 Brak" [ref=e331] [cursor=pointer]:
            - generic [ref=e332]:
              - strong [ref=e333]: Tabliczka znamionowa
              - generic [ref=e334]: Jednostka wewnętrzna JW1
            - generic [ref=e335]: Brak
          - generic [ref=e336]:
            - button "Zrób zdjęcie" [ref=e337] [cursor=pointer]:
              - img [ref=e338]
              - generic [ref=e341]: Zrób zdjęcie
            - button "Galeria" [ref=e342] [cursor=pointer]:
              - img [ref=e343]
              - generic [ref=e347]: Galeria
        - generic [ref=e348]:
          - button "Marka Rotenso" [ref=e349] [cursor=pointer]:
            - img [ref=e351]
            - generic [ref=e354]:
              - strong [ref=e355]: Marka
              - generic [ref=e356]: Rotenso
            - img [ref=e357]
          - button "Model Model JW 1 (TEST)" [ref=e359] [cursor=pointer]:
            - img [ref=e361]
            - generic [ref=e364]:
              - strong [ref=e365]: Model
              - generic [ref=e366]: Model JW 1 (TEST)
            - img [ref=e367]
      - button "Zapisz jednostkę" [ref=e370] [cursor=pointer]
  - 'dialog "Potwierdzenie tabliczki: Jednostka wewnętrzna JW1" [ref=e371]':
    - generic [ref=e372]:
      - generic [ref=e373]:
        - strong [ref=e374]: Sprawdź tabliczkę
        - generic [ref=e375]: Zdjęcie tabliczki JW — jednostka wewnętrzna
      - button "Anuluj potwierdzanie" [ref=e376]:
        - img [ref=e377]
    - generic [ref=e379]:
      - 'img "Tabliczka do potwierdzenia: Jednostka wewnętrzna JW1" [ref=e380]'
      - generic [ref=e381]: Odczyt lokalny
      - generic [ref=e382]: "AI nie uzupełniła wyniku: Nie udało się odczytać tabliczki przez AI.. Sprawdź dane ręcznie."
      - status [ref=e383]: AI nie potwierdziła numeru z wystarczającą pewnością. Sprawdź go znak po znaku z nadrukiem SN na zdjęciu.
      - generic [ref=e384]:
        - generic [ref=e385]: Model
        - textbox "Model" [ref=e386]:
          - /placeholder: Przepisz model z tabliczki
          - text: Rotenso Imoto 3,5 kW (I35Xi R14)
      - generic [ref=e387]:
        - generic [ref=e388]: Numer seryjny
        - textbox "Numer seryjny" [ref=e389]:
          - /placeholder: Przepisz numer seryjny
      - generic [ref=e390] [cursor=pointer]:
        - checkbox "Sprawdziłem numer SN znak po znaku z nadrukiem na zdjęciu." [ref=e391]
        - generic [ref=e392]: Sprawdziłem numer SN znak po znaku z nadrukiem na zdjęciu.
      - generic [ref=e393]: Przed potwierdzeniem uzupełnij model i numer seryjny dokładnie tak, jak na zdjęciu.
    - generic [ref=e394]:
      - button "Wpisz ręcznie" [ref=e395] [cursor=pointer]
      - button "Potwierdź" [disabled] [ref=e396] [cursor=pointer]
```

# Test source

```ts
  453 |       nodes.map((node) => node.getBoundingClientRect().height)
  454 |     ));
  455 |     expect(actionHeights.length).toBeGreaterThanOrEqual(4);
  456 |     for (const height of actionHeights) {
  457 |       expect(height).toBeGreaterThanOrEqual(32);
  458 |       expect(height).toBeLessThanOrEqual(40);
  459 |     }
  460 |     await page.screenshot({ path: testInfo.outputPath('v11.34-step2-compact.png'), fullPage: true });
  461 |   });
  462 | 
  463 |   test('v13.26 — Single ostrzega o różnych seriach i pozwala zapisać faktyczny zestaw', async ({ page }) => {
  464 |     await resetMockSupabase(page);
  465 |     await loginWithoutReset(page, WORKER);
  466 | 
  467 |     await page.evaluate((storeKey) => {
  468 |       const store = JSON.parse(window.localStorage.getItem(storeKey) || '{}');
  469 |       const job = (store.jobs || []).find((item) => item.id === 'mock-job-002');
  470 |       if (job) {
  471 |         job.device_model = 'JW: Rotenso Imoto 5,3 kW (I50Xi R14) | JZ: Rotenso Versu Mirror 5,3 kW (VM50Xo R16)';
  472 |         job.device_serial_number = 'JW: IMOTO-JW-001 | JZ: VERSU-JZ-001';
  473 |         delete job.devices;
  474 |       }
  475 |       window.localStorage.setItem(storeKey, JSON.stringify(store));
  476 |     }, MOCK_STORE_KEY);
  477 | 
  478 |     await page.reload();
  479 |     await page.locator('.statusActionButton[title="W trakcie"]').click();
  480 |     await page.getByText('Klient Testowy B', { exact: true }).click();
  481 |     await page.getByRole('button', { name: 'Tabliczki', exact: true }).click();
  482 |     await expect(page.locator('.mobileDeviceWizard')).toBeVisible();
  483 | 
  484 |     await page.getByRole('button', { name: 'Zapisz urządzenia i tabliczki' }).click();
  485 |     await expect(page.locator('.mobileDevicePairWarning')).toContainText('JZ to Versu Mirror');
  486 |     await expect(page.locator('.mobileDevicePairWarning')).toContainText('JW to Imoto');
  487 |     await expect(page.getByRole('button', { name: 'Zapisz mimo ostrzeżenia' })).toBeVisible();
  488 |     // The first click must not save: the installer can still return to the form.
  489 |     await page.getByRole('button', { name: 'Wróć do edycji' }).click();
  490 |     await expect(page.getByRole('button', { name: 'Zapisz urządzenia i tabliczki' })).toBeVisible();
  491 |     await page.getByRole('button', { name: 'Zapisz urządzenia i tabliczki' }).click();
  492 |     await page.getByRole('button', { name: 'Zapisz mimo ostrzeżenia' }).click();
  493 |     await expect(page.locator('.mobileDeviceWizard')).toBeHidden({ timeout: 20_000 });
  494 | 
  495 |     const savedJob = await page.evaluate((storeKey) => {
  496 |       const store = JSON.parse(window.localStorage.getItem(storeKey) || '{}');
  497 |       return (store.jobs || []).find((item) => item.id === 'mock-job-002') || null;
  498 |     }, MOCK_STORE_KEY);
  499 |     expect(savedJob?.device_model).toContain('Imoto');
  500 |     expect(savedJob?.device_model).toContain('Versu Mirror');
  501 |   });
  502 | 
  503 |   test('automatycznie odczytuje prawdziwe pola modelu i SN z czytelnej tabliczki Rotenso', async ({ page }) => {
  504 |     test.setTimeout(150_000);
  505 |     await resetMockSupabase(page);
  506 |     await loginWithoutReset(page, WORKER);
  507 |     await page.locator('.statusActionButton[title="W trakcie"]').click();
  508 |     await page.getByText('Klient Testowy Multi-Split', { exact: true }).click();
  509 |     await page.getByRole('button', { name: 'Tabliczki', exact: true }).click();
  510 |     await page.locator('.mobileDeviceOverviewOpen').first().click();
  511 |     await page.locator('.mobileMultiIndoorCard').first().click();
  512 | 
  513 |     await page.locator('.nameplateGalleryInput').setInputFiles(syntheticRotensoNameplate);
  514 |     const cropModal = page.locator('.nameplateCropModal');
  515 |     await expect(cropModal).toBeVisible();
  516 |     await page.getByRole('button', { name: 'Zapisz kadr' }).click();
  517 | 
  518 |     const saveAnyway = page.getByRole('button', { name: 'Zapisz mimo to', exact: true });
  519 |     const cropOutcome = await Promise.race([
  520 |       cropModal.waitFor({ state: 'hidden', timeout: 12_000 }).then(() => 'hidden'),
  521 |       saveAnyway.waitFor({ state: 'visible', timeout: 12_000 }).then(() => 'override'),
  522 |     ]);
  523 |     if (cropOutcome === 'override') await saveAnyway.click();
  524 |     await expect(cropModal).toBeHidden();
  525 | 
  526 |     const verifyModal = page.locator('.nameplateVerifyModal');
  527 |     await expect(verifyModal).toBeVisible();
  528 |     await expect.poll(() => page.evaluate(() => {
  529 |       const review = document.querySelector('.nameplateVerifyModal');
  530 |       const heading = review?.querySelector('.nameplateVerifyHeader');
  531 |       if (!heading) return false;
  532 |       const bounds = heading.getBoundingClientRect();
  533 |       const topmost = document.elementFromPoint(
  534 |         bounds.left + bounds.width / 2,
  535 |         bounds.top + bounds.height / 2,
  536 |       );
  537 |       return Boolean(topmost && review.contains(topmost) && review.parentElement === document.body);
  538 |     }), { timeout: 5_000 }).toBe(true);
  539 |     const modelInput = page.getByPlaceholder('Przepisz model z tabliczki');
  540 |     const serialInput = page.getByPlaceholder('Przepisz numer seryjny');
  541 | 
  542 |     await expect(page.locator('.nameplateVerifyMethod')).toBeVisible({ timeout: 120_000 });
  543 |     await expect(modelInput).toHaveValue(/I35Xi R14/i, { timeout: 120_000 });
  544 |     await expect(serialInput).not.toHaveValue(SYNTHETIC_ROTENSO_EAN);
  545 |     await expect(serialInput).not.toHaveValue('TEST-MULTI-JW-1');
  546 | 
  547 |     const automaticSerial = await serialInput.inputValue();
  548 |     if (automaticSerial) {
  549 |       expect(automaticSerial).toBe(SYNTHETIC_ROTENSO_SERIAL);
  550 |     } else {
  551 |       const methodLabel = await page.locator('.nameplateVerifyMethod').textContent();
  552 |       const aiWarningVisible = await page.locator('.nameplateVerifyWarning').isVisible().catch(() => false);
> 553 |       expect(String(methodLabel || '').includes('AI') || aiWarningVisible).toBe(true);
      |                                                                            ^ Error: expect(received).toBe(expected) // Object.is equality
  554 |       await expect(page.getByRole('button', { name: 'Potwierdź', exact: true })).toBeDisabled();
  555 |       await page.getByRole('button', { name: 'Wpisz ręcznie', exact: true }).click();
  556 |       await serialInput.fill(SYNTHETIC_ROTENSO_SERIAL);
  557 |     }
  558 | 
  559 |     const serialReview = page.locator('.nameplateSerialReviewCheck input');
  560 |     if (await serialReview.isVisible()) {
  561 |       await expect(page.getByRole('button', { name: 'Potwierdź', exact: true })).toBeDisabled();
  562 |       await serialReview.check();
  563 |     }
  564 |     await page.getByRole('button', { name: 'Potwierdź', exact: true }).click();
  565 |     await expect(verifyModal).toBeHidden();
  566 |     await expect(page.getByText('Potwierdzona', { exact: true })).toBeVisible();
  567 |   });
  568 | 
  569 |   test('nie pozwala pracownikowi zakończyć zlecenia bez tabliczki JZ i każdej JW', async ({ page }) => {
  570 |     await resetMockSupabase(page);
  571 |     await loginWithoutReset(page, WORKER);
  572 |     await page.locator('.statusActionButton[title="W trakcie"]').click();
  573 |     await page.getByText('Klient Testowy Multi-Split', { exact: true }).click();
  574 | 
  575 |     await expect(page.getByText('Nie można zakończyć zlecenia.', { exact: true })).toHaveCount(0);
  576 |     await expect(page.getByText(/Brakuje: JZ urządzenia 1, JW 1 urządzenia 1, JW 2 urządzenia 1, JW 3 urządzenia 1/)).toHaveCount(0);
  577 |     await expect(page.getByRole('button', { name: 'Zakończ', exact: true })).toBeDisabled();
  578 |     await expect(page.getByRole('button', { name: 'Tabliczki', exact: true })).toBeVisible();
  579 | 
  580 |     await page.getByRole('button', { name: 'Tabliczki', exact: true }).click();
  581 |     await expect(page.locator('.mobileDeviceWizard')).toBeVisible();
  582 |     await expect(page.getByRole('heading', { name: 'Urządzenia', exact: true })).toBeVisible();
  583 |     await expect(page.getByText('Multi', { exact: true })).toBeVisible();
  584 | 
  585 |     // Niepełny zestaw można zapisać, ale zakończenie nadal pozostaje zablokowane.
  586 |     await page.getByRole('button', { name: 'Zapisz urządzenia i tabliczki' }).click();
  587 |     await expect(page.locator('.mobileDeviceWizard')).toBeHidden();
  588 |     await expect(page.getByRole('button', { name: 'Zakończ', exact: true })).toBeDisabled();
  589 | 
  590 |     await page.getByRole('button', { name: 'Tabliczki', exact: true }).click();
  591 |     await page.locator('.mobileDeviceOverviewOpen').first().click();
  592 |     await expect(page.getByText('Tryb: Multi', { exact: true })).toBeVisible();
  593 | 
  594 |     await page.locator('.mobileMultiOutdoorCard').click();
  595 |     await selectNameplateAndCrop(page, page.locator('.nameplateGalleryInput'));
  596 |     await expect(page.getByText('Potwierdzona', { exact: true })).toBeVisible();
  597 |     await page.getByRole('button', { name: 'Zapisz jednostkę' }).click();
  598 | 
  599 |     for (let index = 0; index < 3; index += 1) {
  600 |       await page.locator('.mobileMultiIndoorCard').nth(index).click();
  601 |       await selectNameplateAndCrop(page, page.locator('.nameplateGalleryInput'));
  602 |       await page.getByRole('button', { name: 'Zapisz jednostkę' }).click();
  603 |     }
  604 | 
  605 |     await expect(page.getByText('Tabliczka dodana', { exact: true })).toHaveCount(4);
  606 |     await page.getByRole('button', { name: 'Dalej do podsumowania' }).click();
  607 |     await expect(page.getByText('Wszystkie tabliczki dodane', { exact: true })).toBeVisible();
  608 |     await page.getByRole('button', { name: 'Zapisz urządzenia i tabliczki' }).click();
  609 |     await expect.poll(async () => page.evaluate((storeKey) => {
  610 |       const store = JSON.parse(window.localStorage.getItem(storeKey) || '{}');
  611 |       return (store.photos || []).filter((photo) => (
  612 |         photo.job_id === 'mock-job-005'
  613 |         && photo.photo_kind === 'nameplate'
  614 |         && String(photo.ocr_status || '').toLowerCase() === 'approved'
  615 |         && Boolean(photo.ocr_checked_at)
  616 |       )).length;
  617 |     }, MOCK_STORE_KEY), { timeout: 20_000, intervals: [200, 400, 800] }).toBe(4);
  618 |     await expect(page.locator('.mobileDeviceWizard')).toBeHidden({ timeout: 20_000 });
  619 | 
  620 |     await expect(page.getByText('Wszystkie wymagane zdjęcia tabliczek są zapisane.')).toBeVisible();
  621 |     // Komplet tabliczek usuwa blokadę urządzeń, ale od 12.26 pracownik
  622 |     // nadal musi zapisać protokół klienta przed zakończeniem.
  623 |     await expect(page.getByText(/Najpierw wypełnij, podpisz i zapisz protokół klienta/)).toBeVisible();
  624 |     await expect(page.getByRole('button', { name: 'Zakończ', exact: true })).toBeDisabled();
  625 |   });
  626 | });
  627 | 
```