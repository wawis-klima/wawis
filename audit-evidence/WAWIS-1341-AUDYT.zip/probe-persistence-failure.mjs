import fs from 'node:fs';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results={scope:'Actual photo helpers, real IndexedDB, synthetic quota failure injected only into queue store.add; no production services'};
try{
 const page=await browser.newPage();await page.route('**/__persistence_audit__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>persistence audit</body>'}));await page.goto('http://127.0.0.1:5073/__persistence_audit__');
 results.failure=await page.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');
  const c=document.createElement('canvas');c.width=16;c.height=16;c.getContext('2d').fillRect(0,0,16,16);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([blob],'quota.png',{type:'image/png',lastModified:1});
  let jobs=[{id:'quota-job',photos:[]}];let uploads=0;const errors=[];
  const supabase={
   auth:{async getUser(){return{data:{user:{id:'quota-owner'}},error:null}}},
   from(){return{select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}}},
   storage:{from:()=>({async upload(){uploads++;return{data:null,error:{statusCode:403,message:'synthetic'}}}})},
  };
  const add=IDBObjectStore.prototype.add;
  IDBObjectStore.prototype.add=function(...args){if(this.name==='queued-photos')throw new DOMException('Controlled full device','QuotaExceededError');return add.apply(this,args)};
  let result;
  try{result=await p.uploadJobDocumentationPhotos({supabase,profile:{id:'quota-owner'},jobId:'quota-job',documents:[{file,deviceIndex:0,unitRef:'jz'}],setJobs:fn=>jobs=fn(jobs),onPhotoUploadError:e=>errors.push(String(e?.message||e))})}finally{IDBObjectStore.prototype.add=add}
  const photo=jobs[0].photos[0];const before={result,persisted:(await q.listPhotoQueueItems()).length,uiPhotos:jobs[0].photos.length,uiStatus:photo?.upload_status,uiLabel:photo?.upload_status_label,hasMemoryFile:!!photo?.__localFile,errors,uploads};
  const accepted=p.retryQueuedJobPhoto({supabase,profile:{id:'quota-owner'},photo,setJobs:fn=>jobs=fn(jobs),onPhotoUploadError:e=>errors.push(String(e?.message||e))});
  await new Promise(r=>setTimeout(r,250));
  return{before,retry:{accepted,uploads,persisted:(await q.listPhotoQueueItems()).length,uiStatus:jobs[0].photos[0]?.upload_status},remainingMemoryBytes:photo?.__localFile?.size};
 });
 await page.reload();results.afterReload=await page.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');return{persisted:(await q.listPhotoQueueItems()).length}});
 console.log(JSON.stringify(results,null,2));
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/persistence-failure-results.json',JSON.stringify(results,null,2))}
