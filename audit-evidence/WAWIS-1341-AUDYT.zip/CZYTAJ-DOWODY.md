Dowody końcowego audytu WAWIS 13.41

Główny raport: RAPORT-KONCOWY-1341.md. Żaden plik aplikacji lub jej testów nie został zmieniony. checkout-verification.json zawiera końcowe statusy Git.

full-report.json: cały niezmieniony Playwright; repeated-photo-report.json: 23 przypadki po trzy wykonania; grouped-checks.json: 48 poleceń photos/nameplates/protocol. grouped-checks-shallow dokumentuje wcześniejszy brak historycznego obiektu Git, uzupełniony przed końcowym poprawnym wykonaniem.

Reproduktory probe-*.mjs importują rzeczywiste moduły aplikacji. Zostały przygotowane dla kopii 13.40 w /tmp/wawis-1340-audit i 13.41 w /tmp/wawis-1341-audit, serwerów Vite odpowiednio na 5483 i 5073 oraz systemowego /usr/bin/chromium. Ścieżki w plikach są ścieżkami tego audytu; przy uruchamianiu gdzie indziej trzeba dostosować wyłącznie lokalizacje i porty. Nie kierować adapterów ani testów zapisu do produkcyjnego Supabase.

probe-http-cache.mjs i probe-mixed-versions.mjs kończą się kodem 1, ponieważ sprawdzają niezmiennik bezpieczeństwa, którego badany kod nie spełnia. To oczekiwany RED, nie błąd uruchomienia. probe-manual-race.mjs również raportuje RED trzech powtórzeń. Pozostałe probe zapisują stany diagnostyczne; kod 0 sam w sobie nie oznacza, że wszystkie zaobserwowane zachowania były prawidłowe — odczytać JSON i raport.

W http-cache-results.json pole server.reads jest licznikiem uchwyconym po świeżej kontroli SDK, przed cache eviction. Lista requests obejmuje także późniejszy kontrolny GET po eviction. Zasadniczy dowód to brak sieciowego GET do pobrania obrazu podczas drugiego restore, przy jednoczesnym usunięciu rekordu IDB i potwierdzonym 404 z origin.

original-reproducer-sources zawiera źródła wcześniejszych czterech reproduktorów. run-original-invariants.mjs zapisuje jawne oczekiwania bezpieczeństwa i uruchamia oba commity. original-invariants zawiera wyniki każdej wersji; 13.40 RED, 13.41 GREEN pierwotnych scenariuszy.

release/job-steps.json przedstawia publiczne statusy kroków dwóch prób GitHub Actions. Nie zawiera niedostępnych surowych logów ani artefaktów Closure Gate. Brak dowodu dostawcy/Safari/produkcji jest jawnie oznaczony w raporcie.
