import fs from 'node:fs';
import http from 'node:http';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
let target=5483;
const server=http.createServer(async(req,res)=>{
 if(req.url==='/'){res.writeHead(200,{'content-type':'text/html'});res.end('<!doctype html><body>isolated persistent upgrade audit</body>');return}
 try{const r=await fetch(`http://127.0.0.1:${target}${req.url}`);res.writeHead(r.status,{'content-type':r.headers.get('content-type')||'text/javascript','cache-control':'no-store'});res.end(Buffer.from(await r.arrayBuffer()))}catch(e){res.writeHead(502);res.end(String(e))}
});
await new Promise(r=>server.listen(5673,'127.0.0.1',r));
const profile='/tmp/wawis-1341-evidence/restart-upgrade-profile';let context;const results={scope:'Persistent Chromium closed/relaunched, real13.40 modules upgraded to13.41 on same origin; not native iPhone/PWA/SW'};
try{
 context=await chromium.launchPersistentContext(profile,{executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
 let page=await context.newPage();await page.goto('http://127.0.0.1:5673/');
 results.before=await page.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');
  const c=document.createElement('canvas');c.width=20;c.height=20;c.getContext('2d').fillRect(0,0,20,20);const blob=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([blob],'old-photo.png',{type:'image/png',lastModified:1});
  Object.defineProperty(navigator,'onLine',{get:()=>false,configurable:true});
  await p.uploadJobDocumentationPhotos({supabase:{},profile:{id:'upgrade-owner'},jobId:'upgrade-job',documents:[{file,deviceIndex:0,unitRef:'jz'}]});
  await q.savePhotoQueueItem({id:'local-photo-upload-pre-identity',job_id:'upgrade-job',uploaded_by:'upgrade-owner',local_file:file,photo_kind:'nameplate',device_index:2,unit_ref:'jw'});
  return Promise.all((await q.listPhotoQueueItems()).map(async r=>({id:r.id,size:r.local_file.size,hash:[...new Uint8Array(await crypto.subtle.digest('SHA-256',await r.local_file.arrayBuffer()))].map(b=>b.toString(16).padStart(2,'0')).join(''),path:r.planned_storage_path,generation:r.attempt_generation})));
 });
 await context.close();context=null;target=5073;
 context=await chromium.launchPersistentContext(profile,{executablePath:'/usr/bin/chromium',args:['--no-sandbox']});page=await context.newPage();await page.goto('http://127.0.0.1:5673/');
 results.afterRestart=await page.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');return Promise.all((await q.listPhotoQueueItems()).map(async r=>({id:r.id,size:r.local_file.size,hash:[...new Uint8Array(await crypto.subtle.digest('SHA-256',await r.local_file.arrayBuffer()))].map(b=>b.toString(16).padStart(2,'0')).join(''),path:r.planned_storage_path,generation:r.attempt_generation})))});
 assert.deepEqual(results.afterRestart,results.before);
 results.recovery=await page.evaluate(async()=>{
  const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');const objects=new Map(),rows=new Map();let uploads=0,downloads=0,inserts=0;
  const supabase={auth:{async getUser(){return{data:{user:{id:'upgrade-owner'}},error:null}}},from(){const filters=[];return{select(){return this},eq(k,v){filters.push([k,v]);return this},async maybeSingle(){return{data:[...rows.values()].find(r=>filters.every(([k,v])=>r[k]===v))||null,error:null}},insert(data){return{select(){return{async single(){const row={...data,id:'server-'+ ++inserts};rows.set(data.storage_path,row);return{data:row,error:null}}}}}}}},storage:{from:()=>({async upload(path,blob){uploads++;objects.set(path,blob);return{data:{path},error:null}},async download(path){downloads++;return{data:objects.get(path),error:null}},async createSignedUrl(){return{data:{signedUrl:'https://audit.invalid/upgrade'},error:null}}})}};
  await p.restorePersistedJobPhotos({supabase,profile:{id:'upgrade-owner'}});
  const uploaded=await p.resumePersistedPhotoUploads({supabase,profile:{id:'upgrade-owner'}});
  return{uploaded,remaining:(await q.listPhotoQueueItems()).length,uploads,downloads,inserts,objects:objects.size,rows:rows.size};
 });
 assert.equal(results.recovery.remaining,0);assert.equal(results.recovery.rows,2);assert.equal(results.recovery.objects,2);
 await context.close();context=null;
 // Older schema versions upgrade through the real IndexedDB onupgradeneeded.
 results.schemas=[];
 for(const version of [1,2]){
  context=await chromium.launchPersistentContext(`/tmp/wawis-1341-evidence/legacy-schema-${version}`,{executablePath:'/usr/bin/chromium',args:['--no-sandbox']});page=await context.newPage();await page.goto('http://127.0.0.1:5673/');
  results.schemas.push(await page.evaluate(async version=>{
   await new Promise((resolve,reject)=>{const r=indexedDB.open('wawis-mobile-photo-queue',version);r.onupgradeneeded=()=>r.result.createObjectStore('queued-photos',{keyPath:'id'});r.onerror=()=>reject(r.error);r.onsuccess=()=>{const db=r.result,t=db.transaction('queued-photos','readwrite');t.objectStore('queued-photos').put({id:'legacy',job_id:'old-job',uploaded_by:'upgrade-owner',local_file:new Blob(['legacy-bytes']),upload_status:'local'});t.oncomplete=()=>{db.close();resolve()}}});
   const q=await import('/src/mobile791/modules/photo-offline-queue.js');const records=await q.listPhotoQueueItems();const r=records[0];return{sourceVersion:version,count:records.length,text:await r.local_file.text(),hydrated:!!q.hydratePhotoQueueItem(r,()=> 'blob:fixture')};
  },version));
  assert.equal(results.schemas.at(-1).text,'legacy-bytes');assert.equal(results.schemas.at(-1).hydrated,true);await context.close();context=null;
 }
 results.status='PASS';console.log(JSON.stringify(results,null,2));
}finally{if(context)await context.close();server.closeAllConnections();await new Promise(r=>server.close(r));fs.writeFileSync('/tmp/wawis-1341-evidence/restart-upgrade-results.json',JSON.stringify(results,null,2))}
