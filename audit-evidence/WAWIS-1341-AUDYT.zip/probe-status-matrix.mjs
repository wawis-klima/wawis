import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results=[];
async function pageFor(context){const page=await context.newPage();await page.route('**/__extra_audit__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>isolated extra audit</body>'}));await page.goto('http://127.0.0.1:5073/__extra_audit__');return page;}
try{
 for(const mode of ['upload403','storage-409-proof429','storage-409-proof404','storage-409-proof403','normal-proof503']){
  const context=await browser.newContext();try{
   const page=await pageFor(context);
   const result=await page.evaluate(async mode=>{
    const p=await import('/src/mobile791/modules/photos.js');const q=await import('/src/mobile791/modules/photo-offline-queue.js');
    const c=document.createElement('canvas');c.width=16;c.height=16;c.getContext('2d').fillRect(0,0,16,16);const b=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([b],'proof.png',{type:'image/png',lastModified:1});
    const owner='extra-owner',job='extra-job';const objects=new Map(),rows=new Map();let uploads=0,downloads=0,inserts=0,downloadBytes=0,clock=0;
    if(mode==='no-crypto')Object.defineProperty(globalThis.crypto,'subtle',{value:undefined,configurable:true});
    const supabase={auth:{async getUser(){return{data:{user:{id:owner}},error:null}}},from(){const filters=[];return{select(){return this},eq(k,v){filters.push([k,v]);return this},async maybeSingle(){return{data:[...rows.values()].find(r=>filters.every(([k,v])=>r[k]===v))||null,error:null}},insert(data){return{select(){return{async single(){inserts++;const row={...data,id:'row-'+inserts,created_at:new Date().toISOString()};rows.set(data.storage_path,row);return{data:row,error:null}}}}}}}},storage:{from(){return{
     async upload(path,blob){uploads++;if((mode==='upload503'||mode==='upload429'||mode==='upload403')&&uploads===1)return{data:null,error:{statusCode:Number(mode.slice(6)),message:'temporary server response'}};if(mode.startsWith('storage-409')&&uploads===1){objects.set(path,blob);return{error:{statusCode:409,message:'already exists'}}}if(objects.has(path))return{error:{statusCode:409,message:'already exists'}};objects.set(path,blob);return{data:{path},error:null}},
     async download(path){downloads++;if((mode.includes('-proof'))&&downloads===1)return{data:null,error:{statusCode:Number(mode.split('-proof')[1]),message:'controlled verification response'}};const blob=objects.get(path);if(!blob)return{data:null,error:{statusCode:404,message:'missing'}};downloadBytes+=blob.size;return{data:blob,error:null}},async createSignedUrl(){return{data:{signedUrl:'https://audit.invalid/proof'},error:null}}
    }}}};
    const options={supabase,profile:{id:owner},jobId:job,documents:[{file,deviceIndex:0,unitRef:'jz'}]};
    const initial=await p.uploadJobDocumentationPhotos(options);
    async function state(){const r=(await q.listPhotoQueueItems())[0];return{queue:(await q.listPhotoQueueItems()).length,status:r?.upload_status||'',next:r?.next_attempt_at||'',error:r?.upload_error||'',bytes:r?.local_file?.size||0,uploads,downloads,inserts,objects:objects.size,rows:rows.size,downloadBytes}}
    const afterInitial=await state();const auto=[];const now=Date.now;
    Date.now=()=>now()+clock;
    try{for(let i=0;i<3;i++){clock+=120000;auto.push(await p.resumePersistedPhotoUploads({supabase,profile:{id:owner}}))}}finally{Date.now=now}
    const afterAuto=await state();let manual=null;
    if(mode.includes('-proof')){manual=await p.retryAllPersistedPhotoUploads({supabase,profile:{id:owner}})}
    const final=await state();return{mode,initial,afterInitial,auto,afterAuto,manual,final};
   },mode);results.push(result);console.log(JSON.stringify(result));
  }finally{await context.close()}
 }
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/status-matrix-results.json',JSON.stringify(results,null,2))}
