import fs from 'node:fs';
import assert from 'node:assert/strict';
import {chromium} from '/tmp/wawis-1341-audit/node_modules/@playwright/test/index.mjs';
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',args:['--no-sandbox']});
const results=[];
async function pageFor(context){const page=await context.newPage();await page.route('**/__extra_audit__',r=>r.fulfill({status:200,contentType:'text/html',body:'<!doctype html><body>isolated extra audit</body>'}));await page.goto('http://127.0.0.1:5073/__extra_audit__');return page;}
try{
 for(const mode of ['normal','storage-409-exact','storage-409-proof503','upload503','upload429','no-crypto']){
  const context=await browser.newContext();try{
   const page=await pageFor(context);
   const result=await page.evaluate(async mode=>{
    const p=await import('/src/mobile791/modules/photos.js');const q=await import('/src/mobile791/modules/photo-offline-queue.js');
    const c=document.createElement('canvas');c.width=16;c.height=16;c.getContext('2d').fillRect(0,0,16,16);const b=await new Promise(r=>c.toBlob(r,'image/png'));const file=new File([b],'proof.png',{type:'image/png',lastModified:1});
    const owner='extra-owner',job='extra-job';const objects=new Map(),rows=new Map();let uploads=0,downloads=0,inserts=0,downloadBytes=0,clock=0;
    if(mode==='no-crypto')Object.defineProperty(globalThis.crypto,'subtle',{value:undefined,configurable:true});
    const supabase={auth:{async getUser(){return{data:{user:{id:owner}},error:null}}},from(){const filters=[];return{select(){return this},eq(k,v){filters.push([k,v]);return this},async maybeSingle(){return{data:[...rows.values()].find(r=>filters.every(([k,v])=>r[k]===v))||null,error:null}},insert(data){return{select(){return{async single(){inserts++;const row={...data,id:'row-'+inserts,created_at:new Date().toISOString()};rows.set(data.storage_path,row);return{data:row,error:null}}}}}}}},storage:{from(){return{
     async upload(path,blob){uploads++;if((mode==='upload503'||mode==='upload429')&&uploads===1)return{data:null,error:{statusCode:mode==='upload503'?503:429,message:'temporary server response'}};if(mode.startsWith('storage-409')&&uploads===1){objects.set(path,blob);return{error:{statusCode:409,message:'already exists'}}}if(objects.has(path))return{error:{statusCode:409,message:'already exists'}};objects.set(path,blob);return{data:{path},error:null}},
     async download(path){downloads++;if(mode==='storage-409-proof503'&&downloads===1)return{data:null,error:{statusCode:503,message:'temporary verification unavailable'}};const blob=objects.get(path);if(!blob)return{data:null,error:{statusCode:404,message:'missing'}};downloadBytes+=blob.size;return{data:blob,error:null}},async createSignedUrl(){return{data:{signedUrl:'https://audit.invalid/proof'},error:null}}
    }}}};
    const options={supabase,profile:{id:owner},jobId:job,documents:[{file,deviceIndex:0,unitRef:'jz'}]};
    const initial=await p.uploadJobDocumentationPhotos(options);
    async function state(){const r=(await q.listPhotoQueueItems())[0];return{queue:(await q.listPhotoQueueItems()).length,status:r?.upload_status||'',next:r?.next_attempt_at||'',error:r?.upload_error||'',bytes:r?.local_file?.size||0,uploads,downloads,inserts,objects:objects.size,rows:rows.size,downloadBytes}}
    const afterInitial=await state();const auto=[];const now=Date.now;
    Date.now=()=>now()+clock;
    try{for(let i=0;i<3;i++){clock+=120000;auto.push(await p.resumePersistedPhotoUploads({supabase,profile:{id:owner}}))}}finally{Date.now=now}
    const afterAuto=await state();let manual=null;
    if(mode==='storage-409-proof503'){manual=await p.retryAllPersistedPhotoUploads({supabase,profile:{id:owner}})}
    const final=await state();return{mode,initial,afterInitial,auto,afterAuto,manual,final};
   },mode);results.push(result);console.log(JSON.stringify(result));
  }finally{await context.close()}
 }
 // An active claim is not permission for another page's manual retry.
 {
  const context=await browser.newContext();try{
   const a=await pageFor(context),b=await pageFor(context);
   await a.evaluate(async()=>{const p=await import('/src/mobile791/modules/photos.js');const q=await import('/src/mobile791/modules/photo-offline-queue.js');const file=new File(['lease-proof-bytes'],'proof.jpg',{type:'image/jpeg'});await q.savePhotoQueueItem({id:'local-photo-upload-claim',job_id:'claim-job',uploaded_by:'claim-owner',local_file:file,prepared_file:file,upload_key:'claim',file_fingerprint:'claim-proof',planned_storage_path:'claim-job/claim.jpg'});const read={select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}};const supabase={auth:{async getUser(){return{data:{user:{id:'claim-owner'}},error:null}}},from:()=>read,storage:{from:()=>({upload:()=>new Promise(resolve=>{window.__releaseA=resolve})})}};window.__workerA=p.resumePersistedPhotoUploads({supabase,profile:{id:'claim-owner'}})});
   await a.waitForFunction(()=>Boolean(window.__releaseA));
   const before=await a.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');const r=(await q.listPhotoQueueItems())[0];return{owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,lease:r.lease_until}});
   await b.evaluate(async()=>{const p=await import('/src/mobile791/modules/photos.js');window.__uploadsB=0;const read={select(){return this},eq(){return this},async maybeSingle(){return{data:null,error:null}}};const supabase={auth:{async getUser(){return{data:{user:{id:'claim-owner'}},error:null}}},from:()=>read,storage:{from:()=>({async upload(){window.__uploadsB++;return{error:{statusCode:403,message:'permission denied'}}}})}};p.retryQueuedJobPhoto({supabase,profile:{id:'claim-owner'},photo:{id:'local-photo-upload-claim'}})});
   await b.waitForFunction(()=>window.__uploadsB>0,{timeout:5000});
   const after=await b.evaluate(async()=>{const q=await import('/src/mobile791/modules/photo-offline-queue.js');let r;for(let i=0;i<50;i++){r=(await q.listPhotoQueueItems())[0];if(r.upload_status==='error')break;await new Promise(r=>setTimeout(r,20))}return{uploadsB:window.__uploadsB,owner:r.lease_owner,generation:r.attempt_generation,status:r.upload_status,lease:r.lease_until,bytes:await r.local_file.text()}});
   await a.evaluate(async()=>{window.__releaseA({error:{statusCode:403,message:'old worker response'}});await window.__workerA});
   const result={mode:'manual-retry-borrows-active-claim',before,after};results.push(result);console.log(JSON.stringify(result));
  }finally{await context.close()}
 }
 // An active uploader blocks reconciliation, but integrity download already happened.
 {
  const context=await browser.newContext();try{
   const page=await pageFor(context);
   const result=await page.evaluate(async()=>{
    const p=await import('/src/mobile791/modules/photos.js'),q=await import('/src/mobile791/modules/photo-offline-queue.js');let downloads=0,bytes=0;const rows=[];const blob=new File([new Uint8Array(2*1024*1024)],'prepared.jpg',{type:'image/jpeg'});
    for(let i=0;i<3;i++){const id='local-photo-upload-perf-'+i,path='perf-job/'+i+'.jpg';await q.savePhotoQueueItem({id,job_id:'perf-job',uploaded_by:'perf-owner',local_file:blob,prepared_file:blob,upload_key:'perf-'+i,file_fingerprint:'prepared-'+i,planned_storage_path:path,photo_kind:'nameplate',device_index:1,unit_ref:'jz'});await q.claimPhotoQueueItem(id);rows.push({id:'server-'+i,job_id:'perf-job',storage_path:path})}
    const supabase={from(){const f=[];return{select(){return this},eq(k,v){f.push([k,v]);return this},async maybeSingle(){return{data:rows.find(r=>f.every(([k,v])=>r[k]===v))||null,error:null}}}},storage:{from:()=>({async download(){downloads++;bytes+=blob.size;await new Promise(r=>setTimeout(r,100));return{data:blob,error:null}},async createSignedUrl(){return{data:{signedUrl:'https://audit.invalid/perf'},error:null}}})}};
    const t=performance.now();for(let i=0;i<2;i++)await p.restorePersistedJobPhotos({supabase,profile:{id:'perf-owner'}});
    return{mode:'active-leases-repeated-verification',photos:3,size:blob.size,restoreCalls:2,downloads,bytes,elapsedMs:performance.now()-t,retained:(await q.listPhotoQueueItems()).length,scope:'Synthetic controlled100ms download delay, byte accounting; not measured iPhone or real bandwidth'};
   });results.push(result);console.log(JSON.stringify(result));
  }finally{await context.close()}
 }
}finally{await browser.close();fs.writeFileSync('/tmp/wawis-1341-evidence/additional-results.json',JSON.stringify(results,null,2))}
