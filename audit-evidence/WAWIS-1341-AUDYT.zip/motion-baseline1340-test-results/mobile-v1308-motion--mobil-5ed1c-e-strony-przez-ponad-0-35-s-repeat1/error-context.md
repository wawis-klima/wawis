# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-v1308-motion.spec.js >> @mobile WAWIS 13.08 płynność przejścia na iPhonie >> urządzenia faktycznie animują wysokość w obie strony przez ponad 0,35 s
- Location: tests/e2e/mobile-v1308-motion.spec.js:20:3

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 379
Received:   378
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic "Przełączanie modułów aplikacji" [ref=e5]:
    - button "Montaże" [ref=e6] [cursor=pointer]:
      - generic [ref=e7]: Montaże
    - button "Paliwo" [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Paliwo
    - button "Cennik" [ref=e10] [cursor=pointer]:
      - generic [ref=e11]: Cennik
  - generic [ref=e14]:
    - generic [ref=e15]: W trakcie
    - generic [ref=e16]:
      - generic [ref=e17]:
        - button "Wersja aplikacji 13.40 — otwórz diagnostykę" [ref=e18]: v13.40
        - button "Dodaj nowego klienta" [ref=e19]:
          - img [ref=e20]
        - button "Synchronizuj dane" [ref=e22]:
          - img [ref=e23]
        - generic "Powiadomienia push" [ref=e26]:
          - button "PUSH · brak konfiguracji. Włącz PUSH." [ref=e27] [cursor=pointer]:
            - generic [ref=e28]: PUSH
            - generic [ref=e32]: "OFF"
        - button "Filtruj zlecenia" [ref=e33]:
          - img [ref=e34]
        - button "Wyloguj użytkownika Pracownik Testowy" [ref=e36] [cursor=pointer]: PT
      - 'status "Połączenie: Średnie. Wszystko wysłane. Kliknij, aby otworzyć centrum synchronizacji." [ref=e37]':
        - button "Otwórz Centrum synchronizacji" [ref=e38] [cursor=pointer]:
          - generic [ref=e39]: "Połączenie: Średnie"
          - generic [ref=e41]:
            - text: Wszystko wysłane
            - generic [ref=e43]: ›
    - generic "Statusy zleceń" [ref=e44]:
      - 'button "Nowe: 1" [ref=e45] [cursor=pointer]':
        - generic [ref=e46]:
          - img [ref=e47]
          - generic: "1"
      - 'button "W trakcie: 3" [ref=e48] [cursor=pointer]':
        - generic [ref=e49]:
          - img [ref=e50]
          - generic: "3"
      - 'button "Niezrealizowane: 0" [ref=e51] [cursor=pointer]':
        - generic [ref=e52]:
          - img [ref=e53]
          - generic: "0"
      - 'button "Zakończone: 1" [ref=e54] [cursor=pointer]':
        - generic [ref=e55]:
          - img [ref=e56]
          - generic: "1"
    - generic [ref=e57]:
      - generic [ref=e58]:
        - generic [ref=e59]:
          - button [ref=e60] [cursor=pointer]:
            - img [ref=e61]
            - generic [ref=e64]: Tabliczki
          - button [disabled] [ref=e65]:
            - img [ref=e66]
            - generic [ref=e69]: Protokół
        - generic [ref=e70]:
          - link [ref=e71] [cursor=pointer]:
            - /url: tel:500800900
            - img [ref=e72]
            - generic [ref=e74]: Zadzwoń
          - link [ref=e75] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=Zawiercie%2C%20Multi-Splitowa%203
            - img [ref=e76]
            - generic [ref=e79]: Nawiguj
        - button "Klient Testowy Multi-Split 24.07.26 Zawiercie, Multi-Splitowa 3 PT W trakcie" [expanded] [ref=e82] [cursor=pointer]:
          - generic [ref=e83]:
            - strong [ref=e84]: Klient Testowy Multi-Split
            - generic [ref=e85]: 24.07.26
          - generic [ref=e88]: Zawiercie, Multi-Splitowa 3
          - generic [ref=e89]:
            - generic "Pracownik Testowy" [ref=e92]: PT
            - generic [ref=e93]: W trakcie
      - generic [ref=e97]:
        - generic [ref=e99]:
          - heading "Klient Testowy Multi-Split" [level=2] [ref=e100]
          - generic [ref=e101]:
            - generic [ref=e102]:
              - generic [ref=e103]:
                - img [ref=e104]
                - generic [ref=e107]: Email
              - link "Wyślij email do multi.test@example.test" [ref=e110] [cursor=pointer]:
                - /url: mailto:multi.test@example.test
                - text: multi.test@example.test
            - generic [ref=e111]:
              - generic [ref=e112]:
                - img [ref=e113]
                - generic [ref=e115]: Telefon
              - link "Zadzwoń pod numer 500800900" [ref=e118] [cursor=pointer]:
                - /url: tel:500800900
                - text: "500800900"
            - generic [ref=e119]:
              - generic [ref=e120]:
                - img [ref=e121]
                - generic [ref=e124]: Adres
              - 'link "Otwórz adres w Google Maps: Zawiercie, Multi-Splitowa 3" [ref=e126] [cursor=pointer]':
                - /url: https://www.google.com/maps/search/?api=1&query=Zawiercie%2C%20Multi-Splitowa%203
                - text: Zawiercie, Multi-Splitowa 3
            - generic [ref=e127]:
              - generic [ref=e128]:
                - img [ref=e129]
                - generic [ref=e132]: Data
              - generic [ref=e133]: 24.07.26
            - generic [ref=e134]:
              - generic [ref=e135]:
                - generic [ref=e136]:
                  - img [ref=e137]
                  - generic [ref=e140]: Urządzenia i tabliczki
                - generic [ref=e141]: Multi-split
              - generic [ref=e143]:
                - button "Zwiń Urządzenie 1" [expanded] [active] [ref=e145] [cursor=pointer]:
                  - strong [ref=e146]: Urządzenie 1
                  - generic [ref=e147]: Multi-split
                - generic [ref=e150]:
                  - generic [ref=e151]:
                    - generic [ref=e152]: Urządzenie
                    - generic [ref=e153]: Model / moc
                    - generic [ref=e154]: Tabliczka
                    - generic [ref=e155]: Status
                  - generic [ref=e156]:
                    - button "Dodaj tabliczkę znamionową JZ" [ref=e157] [cursor=pointer]:
                      - generic [ref=e158]:
                        - generic [ref=e159]: JZ
                        - generic [ref=e160]: Jednostka zewnętrzna
                      - generic "Rotenso Multi-Split JZ (TEST)" [ref=e161]:
                        - generic [ref=e162]: Rotenso Multi-Split JZ (TEST)
                      - 'generic "Tabliczka JZ: Brak tabliczki" [ref=e163]':
                        - img [ref=e164]
                        - generic [ref=e167]: Brak tabliczki
                      - img "Brak tabliczki" [ref=e168]:
                        - generic [ref=e169]: —
                    - button "Dodaj tabliczkę znamionową JW1" [ref=e170] [cursor=pointer]:
                      - generic [ref=e171]:
                        - generic [ref=e172]: JW1
                        - generic [ref=e173]: Jednostka wewnętrzna 1
                      - generic "Rotenso Model JW 1 (TEST)" [ref=e174]:
                        - generic [ref=e175]: Rotenso Model JW 1 (TEST)
                      - 'generic "Tabliczka JW1: Brak tabliczki" [ref=e176]':
                        - img [ref=e177]
                        - generic [ref=e180]: Brak tabliczki
                      - img "Brak tabliczki" [ref=e181]:
                        - generic [ref=e182]: —
                    - button "Dodaj tabliczkę znamionową JW2" [ref=e183] [cursor=pointer]:
                      - generic [ref=e184]:
                        - generic [ref=e185]: JW2
                        - generic [ref=e186]: Jednostka wewnętrzna 2
                      - generic "Rotenso Model JW 2 (TEST)" [ref=e187]:
                        - generic [ref=e188]: Rotenso Model JW 2 (TEST)
                      - 'generic "Tabliczka JW2: Brak tabliczki" [ref=e189]':
                        - img [ref=e190]
                        - generic [ref=e193]: Brak tabliczki
                      - img "Brak tabliczki" [ref=e194]:
                        - generic [ref=e195]: —
                    - button "Dodaj tabliczkę znamionową JW3" [ref=e196] [cursor=pointer]:
                      - generic [ref=e197]:
                        - generic [ref=e198]: JW3
                        - generic [ref=e199]: Jednostka wewnętrzna 3
                      - generic "Rotenso Model JW 3 (TEST)" [ref=e200]:
                        - generic [ref=e201]: Rotenso Model JW 3 (TEST)
                      - 'generic "Tabliczka JW3: Brak tabliczki" [ref=e202]':
                        - img [ref=e203]
                        - generic [ref=e206]: Brak tabliczki
                      - img "Brak tabliczki" [ref=e207]:
                        - generic [ref=e208]: —
                  - generic [ref=e209]:
                    - generic [ref=e210]: ●
                    - generic [ref=e211]: Brakuje 4 tabliczek lub potwierdzeń
            - generic [ref=e212]:
              - generic [ref=e213]:
                - img [ref=e214]
                - generic [ref=e219]: Monterzy
              - generic "Pracownik Testowy" [ref=e222]: PT
            - generic [ref=e223]:
              - generic [ref=e224]:
                - img [ref=e225]
                - generic [ref=e228]: Data utworzenia
              - generic [ref=e229]: 24.07.26
          - generic [ref=e230]:
            - button "Edytuj" [ref=e231] [cursor=pointer]:
              - generic [ref=e232]: Edytuj
            - button "Tabliczki" [ref=e233] [cursor=pointer]:
              - generic [ref=e234]: Tabliczki
            - button "Zakończ" [disabled] [ref=e235]:
              - generic [ref=e236]: Zakończ
            - button "Protokół" [disabled] [ref=e237]:
              - generic [ref=e238]: Protokół
            - button "Zamknij" [ref=e239] [cursor=pointer]:
              - generic [ref=e240]: Zamknij
          - generic [ref=e241]: "Krok 1/3: uzupełnij i zsynchronizuj tabliczki. Dopiero potem aktywuje się „Protokół”."
        - generic [ref=e242]:
          - heading "Komentarz administratora" [level=4] [ref=e243]:
            - img [ref=e244]
            - generic [ref=e247]: Komentarz administratora
          - generic [ref=e251]: "Karta testowa multi-split: jeden agregat i trzy jednostki wewnętrzne."
        - generic [ref=e252]:
          - heading "Zdjęcia" [level=4] [ref=e253]:
            - img [ref=e254]
            - generic [ref=e257]: Zdjęcia
          - generic [ref=e260]:
            - generic [ref=e262]: Brak zdjęć.
            - generic "Dodawanie zdjęć do zlecenia" [ref=e263]:
              - generic [ref=e264] [cursor=pointer]:
                - img [ref=e266]
                - generic [ref=e269]: Aparat
              - generic [ref=e270] [cursor=pointer]:
                - img [ref=e272]
                - generic [ref=e276]: Galeria
        - generic [ref=e277]:
          - heading "Monterzy" [level=4] [ref=e278]:
            - img [ref=e279]
            - generic [ref=e284]: Monterzy
          - generic "Wybór monterów" [ref=e288]:
            - button "Administrator Testowy — Nie monter" [ref=e289] [cursor=pointer]:
              - generic [ref=e290]: A. Testowy
            - button "Pracownik Testowy — główny monter (zmiana w edycji montażu)" [disabled] [ref=e291] [cursor=pointer]:
              - generic [ref=e292]: P. Testowy
        - generic [ref=e293]:
          - heading "Komentarze i pytania" [level=4] [ref=e294]:
            - img [ref=e295]
            - generic [ref=e297]: Komentarze i pytania
          - generic [ref=e300]:
            - generic [ref=e302]: Brak komentarzy.
            - textbox "Napisz komentarz..." [ref=e303]
            - button "Dodaj komentarz" [disabled] [ref=e305]
      - generic [ref=e306]:
        - generic [ref=e307]:
          - button [ref=e308] [cursor=pointer]:
            - img [ref=e309]
            - generic [ref=e312]: Tabliczki
          - button [disabled] [ref=e313]:
            - img [ref=e314]
            - generic [ref=e317]: Protokół
        - generic [ref=e318]:
          - link [ref=e319] [cursor=pointer]:
            - /url: tel:500700800
            - img [ref=e320]
            - generic [ref=e322]: Zadzwoń
          - link [ref=e323] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=%C5%81%C3%B3d%C5%BA%2C%20Obca%204
            - img [ref=e324]
            - generic [ref=e327]: Nawiguj
        - button "Klient Testowy D Cudzy 07.05.26 Łódź, Obca 4 AT W trakcie" [ref=e330] [cursor=pointer]:
          - generic [ref=e331]:
            - strong [ref=e332]: Klient Testowy D Cudzy
            - generic [ref=e333]: 07.05.26
          - generic [ref=e336]: Łódź, Obca 4
          - generic [ref=e337]:
            - generic "Administrator Testowy" [ref=e340]: AT
            - generic [ref=e341]: W trakcie
      - generic [ref=e342]:
        - generic [ref=e343]:
          - button [ref=e344] [cursor=pointer]:
            - img [ref=e345]
            - generic [ref=e348]: Tabliczki
          - button [disabled] [ref=e349]:
            - img [ref=e350]
            - generic [ref=e353]: Protokół
        - generic [ref=e354]:
          - link [ref=e355] [cursor=pointer]:
            - /url: tel:500300400
            - img [ref=e356]
            - generic [ref=e358]: Zadzwoń
          - link [ref=e359] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=Krak%C3%B3w%2C%20Ch%C5%82odna%205
            - img [ref=e360]
            - generic [ref=e363]: Nawiguj
        - button "Klient Testowy B 05.05.26 Kraków, Chłodna 5 PT W trakcie" [ref=e366] [cursor=pointer]:
          - generic [ref=e367]:
            - strong [ref=e368]: Klient Testowy B
            - generic [ref=e369]: 05.05.26
          - generic [ref=e372]: Kraków, Chłodna 5
          - generic [ref=e373]:
            - generic "Pracownik Testowy" [ref=e376]: PT
            - generic [ref=e377]: W trakcie
```

# Test source

```ts
  1  | import { devices, expect, test } from '@playwright/test';
  2  | import { ADMIN, WORKER, loginWithoutReset, resetMockSupabase } from './mock-helpers.js';
  3  | 
  4  | const { defaultBrowserType: _ignored, ...iphone14 } = devices['iPhone 14'];
  5  | test.use(iphone14);
  6  | 
  7  | async function openDeviceCard(page) {
  8  |   await resetMockSupabase(page);
  9  |   await loginWithoutReset(page, WORKER);
  10 |   await page.locator('.statusActionButton[title="W trakcie"]').click();
  11 |   const card = page.locator('.mobileJobCard').filter({ hasText: 'Klient Testowy Multi-Split' }).first();
  12 |   await card.locator('.mobileJobCardButton').click();
  13 |   const toggle = page.locator('.jobDeviceDocumentationToggle').first();
  14 |   const section = page.locator('.jobDeviceDocumentationCard .wawisSmoothCollapse').first();
  15 |   await expect(toggle).toBeVisible();
  16 |   return { card, toggle, section };
  17 | }
  18 | 
  19 | test.describe('@mobile WAWIS 13.08 płynność przejścia na iPhonie', () => {
  20 |   test('urządzenia faktycznie animują wysokość w obie strony przez ponad 0,35 s', async ({ page }) => {
  21 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  22 |     const { toggle, section } = await openDeviceCard(page);
  23 |     const initial = await section.evaluate((el) => ({
  24 |       height: el.getBoundingClientRect().height,
  25 |       duration: getComputedStyle(el).transitionDuration,
  26 |     }));
  27 |     expect(initial.height).toBeLessThan(1);
  28 |     expect(initial.duration).toContain('0.44s');
  29 |     await toggle.click();
  30 |     await expect(section).toHaveClass(/isOpen/);
  31 |     await page.waitForTimeout(140);
  32 |     const halfwayUp = await section.evaluate((el) => el.getBoundingClientRect().height);
  33 |     await page.waitForTimeout(420);
  34 |     const fullyOpen = await section.evaluate((el) => el.getBoundingClientRect().height);
> 35 |     expect(fullyOpen).toBeGreaterThan(halfwayUp + 1);
     |                       ^ Error: expect(received).toBeGreaterThan(expected)
  36 |     expect(halfwayUp).toBeGreaterThan(1);
  37 |     const row = section.locator('.deviceUnitDocumentationRow').first();
  38 |     await expect(row).toBeVisible();
  39 | 
  40 |     await toggle.click();
  41 |     await expect(section).not.toHaveClass(/isOpen/);
  42 |     await page.waitForTimeout(140);
  43 |     const halfwayDown = await section.evaluate((el) => el.getBoundingClientRect().height);
  44 |     expect(halfwayDown).toBeLessThan(fullyOpen - 1);
  45 |     expect(halfwayDown).toBeGreaterThan(1);
  46 |     await expect(row).toBeHidden();
  47 |     await toggle.click();
  48 |     await expect(row).toBeVisible();
  49 |   });
  50 | 
  51 |   test('zakończone: animacja komentarza i obrót strzałki działają bez zmian ról', async ({ page }) => {
  52 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  53 |     await resetMockSupabase(page);
  54 |     await loginWithoutReset(page, ADMIN);
  55 |     await page.locator('.statusActionButton[title="Zakończone"]').click();
  56 |     const card = page.locator('.mobileJobCard').filter({ hasText: 'Klient Testowy C Zakończony' }).first();
  57 |     await card.locator('.mobileJobCardButton').click();
  58 |     const toggle = page.getByRole('button', { name: 'Rozwiń komentarz administratora' });
  59 |     await expect(toggle).toHaveAttribute('aria-expanded', 'false');
  60 |     // Stable locator: accessible name changes from Rozwiń to Zwiń on click.
  61 |     const arrow = page.locator('.adminNoteSectionCollapsible .adminNoteToggleChevron').first();
  62 |     await expect(arrow).toBeVisible();
  63 |     await toggle.click();
  64 |     await expect(page.locator('[id^="admin-note-content-"]')).toHaveClass(/isOpen/);
  65 |     const style = await arrow.evaluate(el => ({ duration: getComputedStyle(el).transitionDuration, transform: getComputedStyle(el).transform }));
  66 |     expect(style.duration).toContain('0.4s');
  67 |     await expect(page.locator('[id^="admin-note-content-"]')).toHaveAttribute('aria-hidden', 'false');
  68 |     await page.getByRole('button', { name: 'Zwiń komentarz administratora' }).click();
  69 |     await expect(page.locator('[id^="admin-note-content-"]')).toHaveAttribute('aria-hidden', 'true');
  70 |     await expect(page.locator('[id^="admin-note-content-"] .adminNoteContent')).toHaveCount(0);
  71 |   });
  72 | 
  73 |   test('iOS Ogranicz ruch: bez animacji, zawartość nadal otwiera się i zamyka', async ({ page }) => {
  74 |     await page.emulateMedia({ reducedMotion: 'reduce' });
  75 |     const { toggle, section } = await openDeviceCard(page);
  76 |     const duration = await section.evaluate((el) => getComputedStyle(el).transitionDuration);
  77 |     expect(duration.split(',').every((value) => value.trim() === '0s')).toBe(true);
  78 |     await toggle.click();
  79 |     await expect(section.locator('.deviceUnitDocumentationRow').first()).toBeVisible();
  80 |     await toggle.click();
  81 |     await expect(section.locator('.deviceUnitDocumentationRow').first()).toBeHidden();
  82 |   });
  83 | });
  84 | 
```