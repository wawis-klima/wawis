# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: mobile-v1309-inline-card-motion.spec.js >> @mobile WAWIS 13.09 — płynne szczegóły całej karty >> pracownik: naprawdę animuje wysokość otwierania i zamykania całych szczegółów
- Location: tests/e2e/mobile-v1309-inline-card-motion.spec.js:17:3

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 894.34375
Received:   892.375
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic "Przełączanie modułów aplikacji" [ref=e5]:
    - button "Montaże" [ref=e6] [cursor=pointer]:
      - generic [ref=e7]: Montaże
    - button "Paliwo" [ref=e8] [cursor=pointer]:
      - generic [ref=e9]: Paliwo
    - button "Cennik" [ref=e10] [cursor=pointer]:
      - generic [ref=e11]: Cennik
  - generic [ref=e14]:
    - generic [ref=e15]: W trakcie
    - generic [ref=e16]:
      - generic [ref=e17]:
        - button "Wersja aplikacji 13.41 — otwórz diagnostykę" [ref=e18]: v13.41
        - button "Dodaj nowego klienta" [ref=e19]:
          - img [ref=e20]
        - button "Synchronizuj dane" [ref=e22]:
          - img [ref=e23]
        - generic "Powiadomienia push" [ref=e26]:
          - button "PUSH · brak konfiguracji. Włącz PUSH." [ref=e27] [cursor=pointer]:
            - generic [ref=e28]: PUSH
            - generic [ref=e32]: "OFF"
        - button "Filtruj zlecenia" [ref=e33]:
          - img [ref=e34]
        - button "Wyloguj użytkownika Pracownik Testowy" [ref=e36] [cursor=pointer]: PT
      - 'status "Połączenie: Średnie. Wszystko wysłane. Kliknij, aby otworzyć centrum synchronizacji." [ref=e37]':
        - button "Otwórz Centrum synchronizacji" [ref=e38] [cursor=pointer]:
          - generic [ref=e39]: "Połączenie: Średnie"
          - generic [ref=e41]:
            - text: Wszystko wysłane
            - generic [ref=e43]: ›
    - generic "Statusy zleceń" [ref=e44]:
      - 'button "Nowe: 1" [ref=e45] [cursor=pointer]':
        - generic [ref=e46]:
          - img [ref=e47]
          - generic: "1"
      - 'button "W trakcie: 3" [ref=e48] [cursor=pointer]':
        - generic [ref=e49]:
          - img [ref=e50]
          - generic: "3"
      - 'button "Niezrealizowane: 0" [ref=e51] [cursor=pointer]':
        - generic [ref=e52]:
          - img [ref=e53]
          - generic: "0"
      - 'button "Zakończone: 1" [ref=e54] [cursor=pointer]':
        - generic [ref=e55]:
          - img [ref=e56]
          - generic: "1"
    - generic [ref=e57]:
      - generic [ref=e58]:
        - generic [ref=e59]:
          - button [ref=e60] [cursor=pointer]:
            - img [ref=e61]
            - generic [ref=e64]: Tabliczki
          - button [disabled] [ref=e65]:
            - img [ref=e66]
            - generic [ref=e69]: Protokół
        - generic [ref=e70]:
          - link [ref=e71] [cursor=pointer]:
            - /url: tel:500800900
            - img [ref=e72]
            - generic [ref=e74]: Zadzwoń
          - link [ref=e75] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=Zawiercie%2C%20Multi-Splitowa%203
            - img [ref=e76]
            - generic [ref=e79]: Nawiguj
        - button "Klient Testowy Multi-Split 24.07.26 Zawiercie, Multi-Splitowa 3 PT W trakcie" [ref=e82] [cursor=pointer]:
          - generic [ref=e83]:
            - strong [ref=e84]: Klient Testowy Multi-Split
            - generic [ref=e85]: 24.07.26
          - generic [ref=e88]: Zawiercie, Multi-Splitowa 3
          - generic [ref=e89]:
            - generic "Pracownik Testowy" [ref=e92]: PT
            - generic [ref=e93]: W trakcie
      - generic [ref=e94]:
        - generic [ref=e95]:
          - button [ref=e96] [cursor=pointer]:
            - img [ref=e97]
            - generic [ref=e100]: Tabliczki
          - button [disabled] [ref=e101]:
            - img [ref=e102]
            - generic [ref=e105]: Protokół
        - generic [ref=e106]:
          - link [ref=e107] [cursor=pointer]:
            - /url: tel:500700800
            - img [ref=e108]
            - generic [ref=e110]: Zadzwoń
          - link [ref=e111] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=%C5%81%C3%B3d%C5%BA%2C%20Obca%204
            - img [ref=e112]
            - generic [ref=e115]: Nawiguj
        - button "Klient Testowy D Cudzy 07.05.26 Łódź, Obca 4 AT W trakcie" [ref=e118] [cursor=pointer]:
          - generic [ref=e119]:
            - strong [ref=e120]: Klient Testowy D Cudzy
            - generic [ref=e121]: 07.05.26
          - generic [ref=e124]: Łódź, Obca 4
          - generic [ref=e125]:
            - generic "Administrator Testowy" [ref=e128]: AT
            - generic [ref=e129]: W trakcie
      - generic [ref=e130]:
        - generic [ref=e131]:
          - button [ref=e132] [cursor=pointer]:
            - img [ref=e133]
            - generic [ref=e136]: Tabliczki
          - button [disabled] [ref=e137]:
            - img [ref=e138]
            - generic [ref=e141]: Protokół
        - generic [ref=e142]:
          - link [ref=e143] [cursor=pointer]:
            - /url: tel:500300400
            - img [ref=e144]
            - generic [ref=e146]: Zadzwoń
          - link [ref=e147] [cursor=pointer]:
            - /url: https://www.google.com/maps/search/?api=1&query=Krak%C3%B3w%2C%20Ch%C5%82odna%205
            - img [ref=e148]
            - generic [ref=e151]: Nawiguj
        - button "Klient Testowy B 05.05.26 Kraków, Chłodna 5 PT W trakcie" [expanded] [active] [ref=e154] [cursor=pointer]:
          - generic [ref=e155]:
            - strong [ref=e156]: Klient Testowy B
            - generic [ref=e157]: 05.05.26
          - generic [ref=e160]: Kraków, Chłodna 5
          - generic [ref=e161]:
            - generic "Pracownik Testowy" [ref=e164]: PT
            - generic [ref=e165]: W trakcie
      - generic [ref=e169]:
        - generic [ref=e171]:
          - heading "Klient Testowy B" [level=2] [ref=e172]
          - generic [ref=e173]:
            - generic [ref=e174]:
              - generic [ref=e175]:
                - img [ref=e176]
                - generic [ref=e179]: Email
              - link "Wyślij email do klient.b@example.test" [ref=e182] [cursor=pointer]:
                - /url: mailto:klient.b@example.test
                - text: klient.b@example.test
            - generic [ref=e183]:
              - generic [ref=e184]:
                - img [ref=e185]
                - generic [ref=e187]: Telefon
              - link "Zadzwoń pod numer 500300400" [ref=e190] [cursor=pointer]:
                - /url: tel:500300400
                - text: "500300400"
            - generic [ref=e191]:
              - generic [ref=e192]:
                - img [ref=e193]
                - generic [ref=e196]: Adres
              - 'link "Otwórz adres w Google Maps: Kraków, Chłodna 5" [ref=e198] [cursor=pointer]':
                - /url: https://www.google.com/maps/search/?api=1&query=Krak%C3%B3w%2C%20Ch%C5%82odna%205
                - text: Kraków, Chłodna 5
            - generic [ref=e199]:
              - generic [ref=e200]:
                - img [ref=e201]
                - generic [ref=e204]: Data
              - generic [ref=e205]: 05.05.26
            - generic [ref=e206]:
              - generic [ref=e207]:
                - generic [ref=e208]:
                  - img [ref=e209]
                  - generic [ref=e212]: Urządzenia i tabliczki
                - generic [ref=e213]: Single-split
              - button "Rozwiń Urządzenie 1" [ref=e217] [cursor=pointer]:
                - strong [ref=e218]: Urządzenie 1
                - generic [ref=e219]: Single-split
            - generic [ref=e220]:
              - generic [ref=e221]:
                - img [ref=e222]
                - generic [ref=e227]: Monterzy
              - generic "Pracownik Testowy" [ref=e230]: PT
            - generic [ref=e231]:
              - generic [ref=e232]:
                - img [ref=e233]
                - generic [ref=e236]: Data utworzenia
              - generic [ref=e237]: 21.04.26
          - generic [ref=e238]:
            - button "Edytuj" [ref=e239] [cursor=pointer]:
              - generic [ref=e240]: Edytuj
            - button "Tabliczki" [ref=e241] [cursor=pointer]:
              - generic [ref=e242]: Tabliczki
            - button "Zakończ" [disabled] [ref=e243]:
              - generic [ref=e244]: Zakończ
            - button "Protokół" [disabled] [ref=e245]:
              - generic [ref=e246]: Protokół
            - button "Zamknij" [ref=e247] [cursor=pointer]:
              - generic [ref=e248]: Zamknij
          - generic [ref=e249]: "Krok 1/3: uzupełnij i zsynchronizuj tabliczki. Dopiero potem aktywuje się „Protokół”."
        - generic [ref=e250]:
          - heading "Komentarz administratora" [level=4] [ref=e251]:
            - img [ref=e252]
            - generic [ref=e255]: Komentarz administratora
          - generic [ref=e259]: Brak komentarza.
        - generic [ref=e260]:
          - heading "Zdjęcia" [level=4] [ref=e261]:
            - img [ref=e262]
            - generic [ref=e265]: Zdjęcia
          - generic [ref=e268]:
            - generic [ref=e270]: Brak zdjęć.
            - generic "Dodawanie zdjęć do zlecenia" [ref=e271]:
              - generic [ref=e272] [cursor=pointer]:
                - img [ref=e274]
                - generic [ref=e277]: Aparat
              - generic [ref=e278] [cursor=pointer]:
                - img [ref=e280]
                - generic [ref=e284]: Galeria
        - generic [ref=e285]:
          - heading "Monterzy" [level=4] [ref=e286]:
            - img [ref=e287]
            - generic [ref=e292]: Monterzy
          - generic "Wybór monterów" [ref=e296]:
            - button "Administrator Testowy — Nie monter" [ref=e297] [cursor=pointer]:
              - generic [ref=e298]: A. Testowy
            - button "Pracownik Testowy — główny monter (zmiana w edycji montażu)" [disabled] [ref=e299] [cursor=pointer]:
              - generic [ref=e300]: P. Testowy
        - generic [ref=e301]:
          - heading "Komentarze i pytania" [level=4] [ref=e302]:
            - img [ref=e303]
            - generic [ref=e305]: Komentarze i pytania
          - generic [ref=e308]:
            - generic [ref=e310]: Brak komentarzy.
            - textbox "Napisz komentarz..." [ref=e311]
            - button "Dodaj komentarz" [disabled] [ref=e313]
```

# Test source

```ts
  1  | import { devices, expect, test } from '@playwright/test';
  2  | import { ADMIN, WORKER, loginWithoutReset, resetMockSupabase } from './mock-helpers.js';
  3  | 
  4  | const { defaultBrowserType: _ignored, ...iphone14 } = devices['iPhone 14'];
  5  | test.use(iphone14);
  6  | 
  7  | async function openList(page, role = WORKER, status = 'W trakcie', name = 'Klient Testowy B') {
  8  |   await resetMockSupabase(page);
  9  |   await loginWithoutReset(page, role);
  10 |   await page.locator('.statusActionButton[title="' + status + '"]').click();
  11 |   const card = page.locator('.mobileJobCard').filter({ hasText: name }).first();
  12 |   await expect(card).toBeVisible();
  13 |   return card;
  14 | }
  15 | 
  16 | test.describe('@mobile WAWIS 13.09 — płynne szczegóły całej karty', () => {
  17 |   test('pracownik: naprawdę animuje wysokość otwierania i zamykania całych szczegółów', async ({ page }) => {
  18 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  19 |     const card = await openList(page);
  20 |     await card.locator('.mobileJobCardButton').click();
  21 |     const wrapper = page.locator('.wawisInlineJobMotion').first();
  22 |     await expect(wrapper).toBeVisible();
  23 |     await expect(wrapper).toHaveClass(/isOpen/);
  24 |     const duration = await wrapper.evaluate((el) => getComputedStyle(el).transitionDuration);
  25 |     expect(duration).toContain('0.52s');
  26 |     await page.waitForTimeout(150);
  27 |     const midOpen = await wrapper.evaluate((el) => el.getBoundingClientRect().height);
  28 |     await page.waitForTimeout(490);
  29 |     const fullyOpen = await wrapper.evaluate((el) => el.getBoundingClientRect().height);
> 30 |     expect(fullyOpen).toBeGreaterThan(midOpen + 2);
     |                       ^ Error: expect(received).toBeGreaterThan(expected)
  31 |     expect(midOpen).toBeGreaterThan(1);
  32 |     await expect(wrapper.locator('.mobileInlineJobDetails')).toBeVisible();
  33 | 
  34 |     await card.locator('.mobileJobCardButton').click();
  35 |     await expect(card.locator('.mobileJobCardButton')).toHaveAttribute('aria-expanded', 'false');
  36 |     await expect(wrapper).not.toHaveClass(/isOpen/);
  37 |     // The panel stays mounted during closing instead of disappearing instantly.
  38 |     await expect(wrapper.locator('.mobileInlineJobDetails')).toHaveCount(1);
  39 |     await page.waitForTimeout(150);
  40 |     const midClose = await wrapper.evaluate((el) => el.getBoundingClientRect().height);
  41 |     expect(midClose).toBeLessThan(fullyOpen - 2);
  42 |     expect(midClose).toBeGreaterThan(1);
  43 |     await expect(page.locator('.mobileInlineJobDetails')).toHaveCount(0);
  44 |     await card.locator('.mobileJobCardButton').click();
  45 |     await expect(page.locator('.mobileInlineJobDetails')).toBeVisible();
  46 |   });
  47 | 
  48 |   test('administrator: Zakończone rozwija się i chowa zarówno z karty jak z przycisku Zamknij', async ({ page }) => {
  49 |     await page.emulateMedia({ reducedMotion: 'no-preference' });
  50 |     const card = await openList(page, ADMIN, 'Zakończone', 'Klient Testowy C Zakończony');
  51 |     await card.locator('.mobileJobCardButton').click();
  52 |     const details = page.locator('.mobileInlineJobDetails');
  53 |     await expect(details).toBeVisible();
  54 |     await page.getByRole('button', { name: 'Zamknij', exact: true }).click();
  55 |     const wrapper = page.locator('.wawisInlineJobMotion');
  56 |     await expect(wrapper).toHaveAttribute('aria-hidden', 'true');
  57 |     await expect(wrapper.locator('.mobileInlineJobDetails')).toHaveCount(1);
  58 |     await expect(details).toHaveCount(0);
  59 |     await card.locator('.mobileJobCardButton').click();
  60 |     await expect(details).toBeVisible();
  61 |   });
  62 | 
  63 |   test('iOS Ogranicz ruch: animacja wyłączona, otwieranie i zamykanie nadal działa', async ({ page }) => {
  64 |     await page.emulateMedia({ reducedMotion: 'reduce' });
  65 |     const card = await openList(page);
  66 |     await card.locator('.mobileJobCardButton').click();
  67 |     const wrapper = page.locator('.wawisInlineJobMotion');
  68 |     await expect(wrapper).toBeVisible();
  69 |     const durations = await wrapper.evaluate((el) => getComputedStyle(el).transitionDuration);
  70 |     expect(durations.split(',').every((duration) => duration.trim() === '0s')).toBe(true);
  71 |     await card.locator('.mobileJobCardButton').click();
  72 |     await expect(page.locator('.mobileInlineJobDetails')).toHaveCount(0);
  73 |   });
  74 | });
  75 | 
```